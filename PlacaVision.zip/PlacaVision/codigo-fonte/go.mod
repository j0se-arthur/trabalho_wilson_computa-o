module placas

go 1.22

require github.com/mattn/go-sqlite3 v1.14.24

replace github.com/mattn/go-sqlite3 => ./third_party/go-sqlite3
