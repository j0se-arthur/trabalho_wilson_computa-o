@echo off
REM Requer Go 1.22+ e MinGW-w64 (gcc) no PATH. Veja ..\docs\manual_instalacao.md
set CGO_ENABLED=1
go build -trimpath -ldflags "-s -w" -o PlacaVision.exe .
if errorlevel 1 (echo Falha na compilacao) else (echo Gerado: PlacaVision.exe)
pause
