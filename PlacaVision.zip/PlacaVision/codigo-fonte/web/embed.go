// Pacote web embute templates e arquivos estáticos no executável.
package web

import "embed"

//go:embed templates static
var FS embed.FS
