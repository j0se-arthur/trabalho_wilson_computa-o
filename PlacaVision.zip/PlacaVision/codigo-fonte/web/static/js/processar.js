'use strict';
(() => {
  const drop = $('#drop'), input = $('#file'), prev = $('#preview'), msg = $('#msg');
  let file = null;
  const ALLOWED = ['image/jpeg', 'image/png', 'image/bmp'];
  const EXT = /\.(jpe?g|png|bmp)$/i;
  function error(t) { msg.textContent = t; msg.hidden = !t; }
  function setFile(f) {
    error('');
    if (!f) return;
    if (!EXT.test(f.name) || (f.type && !ALLOWED.includes(f.type))) return error('Formato não permitido. Use JPG, JPEG, PNG ou BMP.');
    if (f.size > 15 * 1024 * 1024) return error('O arquivo excede o limite de 15 MB.');
    file = f;
    const url = URL.createObjectURL(f), img = $('#preview-img');
    img.onload = () => { $('#preview-meta').textContent = `${img.naturalWidth}×${img.naturalHeight}px · ${(f.size / 1024).toFixed(0)} KB`; };
    img.onerror = () => { error('Não foi possível exibir esta imagem (arquivo corrompido ou formato não suportado pelo navegador). O servidor ainda tentará processá-la.'); };
    img.src = url;
    $('#preview-name').textContent = f.name;
    drop.hidden = true; prev.hidden = false; $('#result').hidden = true;
  }
  drop.addEventListener('click', () => input.click());
  drop.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); } });
  input.addEventListener('change', () => setFile(input.files[0]));
  ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', e => setFile(e.dataTransfer.files[0]));
  $('#clear').addEventListener('click', () => { file = null; input.value = ''; prev.hidden = true; drop.hidden = false; $('#result').hidden = true; error(''); });

  $('#start').addEventListener('click', async () => {
    if (!file) return;
    const btn = $('#start'); btn.disabled = true; error('');
    const prog = $('#progress'), res = $('#result');
    prog.hidden = false; res.hidden = true; $('#progress-text').textContent = 'Processando a imagem no servidor (pipeline de PDI em Go)…';
    const fd = new FormData(); fd.append('image', file);
    try {
      const a = await api('/api/analyze', { method: 'POST', body: fd });
      prog.hidden = true; res.hidden = false;
      renderAnalysis(res, a, { getLang: () => $('#lang').value });
      res.scrollIntoView({ behavior: 'smooth' });
      // executa o OCR automaticamente em todas as placas detectadas, uma de cada vez
      for (const b of res.querySelectorAll('[data-act=ocr]')) { b.click(); await new Promise(r => { const t = setInterval(() => { if (!b.disabled) { clearInterval(t); r(); } }, 150); }); }
    } catch (e) {
      prog.hidden = true; error(e.message);
      if (e.body && e.body.analysis) { res.hidden = false; renderAnalysis(res, e.body.analysis, {}); }
    } finally { btn.disabled = false; }
  });

  const names = { 'frontal.jpg': 'Placa frontal', 'inclinada.jpg': 'Placa inclinada', 'pouca_luz.jpg': 'Pouca luz', 'baixa_resolucao.jpg': 'Baixa resolução', 'dois_carros.jpg': 'Dois veículos', 'sem_placa.jpg': 'Sem placa' };
  $('#examples').innerHTML = Object.entries(names).map(([f, n]) => `<button type="button" data-f="${f}" title="${n}"><img src="/static/exemplos/${f}" alt="${n}"></button>`).join('');
  $('#examples').addEventListener('click', async e => {
    const b = e.target.closest('button'); if (!b) return;
    const blob = await (await fetch('/static/exemplos/' + b.dataset.f)).blob();
    setFile(new File([blob], b.dataset.f, { type: blob.type }));
  });
})();
