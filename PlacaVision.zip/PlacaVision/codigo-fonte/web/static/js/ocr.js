'use strict';
// OCR no navegador com Tesseract.js (WebAssembly), todos os arquivos servidos localmente.
const OCR = (() => {
  let worker = null, workerLang = null;
  async function get(lang, onStatus) {
    if (worker && workerLang === lang) return worker;
    if (worker) { await worker.terminate(); worker = null; }
    worker = await Tesseract.createWorker(lang, 1, {
      workerPath: '/static/vendor/tesseract/worker.min.js',
      corePath: '/static/vendor/tesseract/core',
      langPath: '/static/vendor/tesseract/lang',
      gzip: true, workerBlobURL: false,
      logger: m => { if (onStatus) onStatus(m); },
    });
    workerLang = lang;
    return worker;
  }
  // Lê uma placa tentando cada versão da imagem em dois modos de segmentação
  // (7 = linha única, 6 = bloco). O texto é devolvido como o Tesseract reconheceu;
  // só quebras de linha viram espaço e as pontas são aparadas.
  async function recognizePlate(urls, lang, onStatus) {
    const w = await get(lang, onStatus);
    const attempts = [];
    let best = null;
    for (const u of urls) {
      for (const psm of ['7', '6']) {
        await w.setParameters({ tessedit_pageseg_mode: psm, preserve_interword_spaces: '1' });
        const { data } = await w.recognize(u.url);
        const text = (data.text || '').replace(/\s*\n\s*/g, ' ').trim();
        const a = { version: u.label, psm, text, confidence: Math.round(data.confidence * 10) / 10 };
        attempts.push(a);
        if (text && (!best || a.confidence > best.confidence)) best = a;
      }
    }
    return { best, attempts };
  }
  return { recognizePlate };
})();
