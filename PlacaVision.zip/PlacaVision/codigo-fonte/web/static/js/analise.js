'use strict';
(async () => {
  const id = document.body.dataset.id;
  try {
    const a = await api('/api/analyses/' + id);
    $('#title').textContent = `Análise #${a.id} – ${a.filename}`;
    renderAnalysis($('#result'), a, { getLang: () => 'ara+eng' });
  } catch (e) { const m = $('#msg'); m.textContent = e.message; m.hidden = false; }
  $('#del').addEventListener('click', async () => {
    if (!confirm('Excluir esta análise e todos os arquivos gerados?')) return;
    try { await api('/api/analyses/' + id, { method: 'DELETE' }); location.href = '/historico'; } catch (e) { toast(e.message); }
  });
})();
