'use strict';
// Renderização do resultado de uma análise (etapas, placas e OCR) usada em
// "Processar" e na página de detalhe do histórico.
const STEP_GROUPS = [
  ['Aquisição e pré-processamento', n => ['original', 'cinza', 'gaussiano', 'bilateral', 'equalizada', 'limiar_adaptativo'].includes(n)],
  ['Detecção de bordas e morfologia', n => ['sobel', 'bordas', 'morfologia'].includes(n)],
  ['Contornos e detecção da placa', n => ['contornos', 'deteccao'].includes(n)],
];
function fig(a, st) {
  if (!st.file) return '';
  return `<figure><img loading="lazy" src="/results/${a.id}/${esc(st.file)}" alt="${esc(st.title)}"><figcaption><b>${esc(st.title)}</b><span>${fmtMs(st.millis)}${st.status !== 'ok' ? ' · ERRO' : ''}${st.detail ? ' · ' + esc(st.detail) : ''}</span></figcaption></figure>`;
}
function plateUrls(a, i) {
  const labels = [['cinza', 'cinza normalizada'], ['otsu', 'Otsu'], ['adaptativa', 'adaptativa']];
  return labels.map(([k, label]) => {
    const st = (a.steps || []).find(s => s.name === `placa${i + 1}_${k}` && s.file);
    return st ? { label, url: `/results/${a.id}/${st.file}` } : null;
  }).filter(Boolean);
}
function plateBlock(a, p, i) {
  const crop = (a.steps || []).find(s => s.name === `placa${i + 1}_recorte`);
  const vers = (a.steps || []).filter(s => s.name.startsWith(`placa${i + 1}_`) && s.name !== `placa${i + 1}_recorte`);
  const done = p.ocrStatus !== 'pendente';
  const gt = p.groundTruth ?? '';
  return `<div class="plate" data-plate="${p.id}" data-index="${i}">
    <div class="plate-head">
      ${crop && crop.file ? `<img class="zoom" src="/results/${a.id}/${esc(crop.file)}" alt="Placa ${i + 1} recortada">` : ''}
      <div style="flex:1;min-width:240px">
        <strong>Placa ${i + 1}</strong> <span class="muted">· posição (${p.x}, ${p.y}) · ${p.w}×${p.h} px · pontuação ${p.score} · ${p.method === 'perspectiva' ? 'com correção de perspectiva' : 'recorte convencional'}</span>
        <div class="plate-text" dir="auto" data-role="text">${done ? (p.text ? esc(p.text) : '<span class="muted" style="font-size:1rem">sem resultado do OCR</span>') : '<span class="muted" style="font-size:1rem">OCR pendente</span>'}</div>
        <div class="muted" data-role="conf">${done && p.text ? `confiança do OCR: ${p.confidence}% · idiomas: ${esc(p.ocrLang)}` : ''}</div>
        <div class="row" style="margin-top:10px">
          <button class="btn small" type="button" data-act="ocr">${done ? 'Executar OCR novamente' : 'Executar OCR'}</button>
          <label class="field" style="flex-direction:row;align-items:center;gap:6px">Texto correto:
            <input type="text" data-role="truth" value="${esc(gt)}" maxlength="64" placeholder="gabarito (opcional)" size="14" dir="auto"></label>
          <button class="btn small" type="button" data-act="truth">Salvar gabarito</button>
        </div>
        <div class="muted" data-role="cer" style="margin-top:6px">${p.cer != null ? `CER desta leitura: ${pct(p.cer)}` : ''}</div>
      </div>
    </div>
    ${vers.length ? `<details style="margin-top:12px"><summary class="muted">Versões tratadas da placa</summary><div class="gallery" style="margin-top:10px">${vers.map(s => fig(a, s)).join('')}</div></details>` : ''}
    <div data-role="attempts"></div>
  </div>`;
}
function renderAnalysis(root, a, opts = {}) {
  const steps = a.steps || [];
  const total = steps.reduce((t, s) => t + s.millis, 0);
  let html = `<div class="card"><div class="stats-line">
    <span>Arquivo: <b>${esc(a.filename)}</b></span><span>Dimensões: <b>${a.width}×${a.height}px</b></span>
    <span>Placas: <b>${a.totalPlates}</b></span><span>Tempo do pipeline: <b>${fmtMs(a.processingTime)}</b></span><span>Status: ${statusBadge(a.status)}</span></div>`;
  if (a.original) html += `<div class="row"><img class="zoom" style="max-width:100%;max-height:360px;border-radius:10px;border:1px solid var(--line)" src="/results/${a.id}/${esc(a.original)}" alt="Imagem original preservada"></div>`;
  html += `</div>`;
  if (a.totalPlates === 0 && a.status !== 'erro') html += `<p class="msg ok" style="background:#2a230f;border-color:#78350f;color:#fde68a">Nenhuma placa foi localizada nesta imagem. Veja abaixo as etapas intermediárias para entender o motivo.</p>`;
  html += `<div class="card"><h2>Placas</h2>${a.plates && a.plates.length ? a.plates.map((p, i) => plateBlock(a, p, i)).join('') : '<p class="muted">Nenhuma placa detectada.</p>'}</div>`;
  html += `<div class="card"><h2>Etapas do processamento</h2>`;
  for (const [title, test] of STEP_GROUPS) {
    const g = steps.filter(s => test(s.name));
    if (g.length) html += `<h3>${title}</h3><div class="gallery">${g.map(s => fig(a, s)).join('')}</div>`;
  }
  html += `<h3>Tempo por etapa</h3><div class="table-wrap"><table><thead><tr><th>Etapa</th><th>Status</th><th>Tempo</th></tr></thead><tbody>${steps.map(s => `<tr><td>${esc(s.title)}</td><td>${s.status === 'ok' ? '<span class="badge ok">ok</span>' : '<span class="badge err">erro</span>'}</td><td>${fmtMs(s.millis)}</td></tr>`).join('')}<tr><td><b>Soma das etapas</b></td><td></td><td><b>${fmtMs(total)}</b></td></tr></tbody></table></div></div>`;
  root.innerHTML = html;
  root.querySelectorAll('.plate').forEach(el => bindPlate(el, a, opts));
}
function bindPlate(el, a, opts) {
  const i = +el.dataset.index, pid = el.dataset.plate;
  const p = a.plates[i];
  el.querySelector('[data-act=ocr]').addEventListener('click', async ev => {
    const btn = ev.currentTarget, textEl = el.querySelector('[data-role=text]'), confEl = el.querySelector('[data-role=conf]'), att = el.querySelector('[data-role=attempts]');
    const lang = (opts.getLang ? opts.getLang() : 'ara+eng');
    let finished = false;
    btn.disabled = true; textEl.innerHTML = '<span class="muted" style="font-size:1rem">carregando OCR…</span>';
    att.innerHTML = '<div class="pbar"><i></i></div>';
    try {
      const { best, attempts } = await OCR.recognizePlate(plateUrls(a, i), lang, m => {
        if (m.progress != null) { const b = att.querySelector('.pbar i'); if (b) b.style.width = Math.round(m.progress * 100) + '%'; }
        if (m.status && !finished) textEl.innerHTML = `<span class="muted" style="font-size:1rem">${esc(m.status)}…</span>`;
      });
      finished = true;
      const text = best ? best.text : '', conf = best ? best.confidence : 0;
      await api(`/api/plates/${pid}/ocr`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text, confidence: conf, lang }) });
      p.text = text; p.ocrStatus = text ? 'reconhecido' : 'sem_resultado'; p.confidence = conf; p.ocrLang = lang;
      textEl.innerHTML = text ? esc(text) : '<span class="muted" style="font-size:1rem">sem resultado do OCR</span>';
      confEl.textContent = text ? `confiança do OCR: ${conf}% · idiomas: ${lang} · versão: ${best.version} (PSM ${best.psm})` : 'o OCR não devolveu texto em nenhuma versão da placa';
      att.innerHTML = `<table class="attempts"><thead><tr><th>Versão</th><th>PSM</th><th>Texto lido</th><th>Confiança</th></tr></thead><tbody>${attempts.map(t => `<tr><td>${esc(t.version)}</td><td>${t.psm}</td><td dir="auto">${esc(t.text || '—')}</td><td>${t.confidence}%</td></tr>`).join('')}</tbody></table>`;
      btn.textContent = 'Executar OCR novamente';
      if (p.groundTruth != null) { const g = await api('/api/analyses/' + a.id); const np = g.plates[i]; el.querySelector('[data-role=cer]').textContent = np.cer != null ? `CER desta leitura: ${pct(np.cer)}` : ''; }
    } catch (e) {
      finished = true;
      textEl.innerHTML = '<span class="muted" style="font-size:1rem">falha no OCR</span>'; att.innerHTML = `<p class="msg">${esc(e.message)}</p>`;
    } finally { btn.disabled = false; }
  });
  el.querySelector('[data-act=truth]').addEventListener('click', async () => {
    const v = el.querySelector('[data-role=truth]').value;
    try {
      await api(`/api/plates/${pid}/truth`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ truth: v }) });
      const g = await api('/api/analyses/' + a.id), np = g.plates[i];
      p.groundTruth = np.groundTruth;
      el.querySelector('[data-role=cer]').textContent = np.cer != null ? `CER desta leitura: ${pct(np.cer)}${np.cer === 0 ? ' (leitura exata)' : ''}` : (v.trim() && np.ocrStatus === 'pendente' ? 'gabarito salvo; execute o OCR para calcular o CER' : '');
      toast('Gabarito salvo');
    } catch (e) { toast(e.message); }
  });
}
