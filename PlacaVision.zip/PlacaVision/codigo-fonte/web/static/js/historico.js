'use strict';
(() => {
  const PAGE = 15; let offset = 0, total = 0, timer;
  async function load() {
    const q = new URLSearchParams({ q: $('#q').value, status: $('#status').value, limit: PAGE, offset });
    try {
      const d = await api('/api/analyses?' + q); total = d.total;
      $('#list').innerHTML = analysesTable(d.items);
      $('#count').textContent = total ? `${offset + 1}–${Math.min(offset + PAGE, total)} de ${total}` : '';
      $('#prev').disabled = offset === 0; $('#next').disabled = offset + PAGE >= total;
    } catch (e) { $('#list').innerHTML = `<p class="msg">${esc(e.message)}</p>`; }
  }
  $('#q').addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(() => { offset = 0; load(); }, 250); });
  $('#status').addEventListener('change', () => { offset = 0; load(); });
  $('#prev').addEventListener('click', () => { offset = Math.max(0, offset - PAGE); load(); });
  $('#next').addEventListener('click', () => { offset += PAGE; load(); });
  load();
})();
