'use strict';
(async () => {
  try {
    const s = await api('/api/stats');
    $('#k-images').textContent = s.images; $('#k-plates').textContent = s.plates;
    $('#k-rec').textContent = s.recognized; $('#k-nores').textContent = s.noResult;
    $('#k-rate').textContent = s.recognized + s.noResult ? pct(s.successRate) : '–';
    $('#k-time').textContent = s.images ? fmtMs(s.avgMillis) : '–';
    $('#k-cer').textContent = s.avgCER != null ? pct(s.avgCER) : '–';
    $('#k-exact').textContent = s.exactMatchRate != null ? pct(s.exactMatchRate) : '–';
    $('#eval-note').textContent = s.evaluated ? `CER e acerto exato calculados sobre ${s.evaluated} placa(s) com gabarito informado.` : 'Para ver CER e acerto exato, informe o texto correto (gabarito) das placas na página de cada análise.';
    if (s.pending) $('#eval-note').textContent += ` Há ${s.pending} placa(s) com OCR pendente.`;
    const css = getComputedStyle(document.documentElement);
    Chart.defaults.color = '#8b98a5'; Chart.defaults.borderColor = '#27323d';
    new Chart($('#c-ocr'), { type: 'doughnut', data: { labels: ['Texto reconhecido', 'Sem resultado', 'OCR pendente'], datasets: [{ data: [s.recognized, s.noResult, s.pending], backgroundColor: ['#10b981', '#ef4444', '#475569'], borderWidth: 0 }] }, options: { maintainAspectRatio: false } });
    new Chart($('#c-day'), { type: 'bar', data: { labels: (s.perDay || []).map(d => d.day.slice(5).split('-').reverse().join('/')), datasets: [{ label: 'Imagens', data: (s.perDay || []).map(d => d.images), backgroundColor: '#38bdf8' }, { label: 'Placas', data: (s.perDay || []).map(d => d.plates), backgroundColor: '#10b981' }] }, options: { maintainAspectRatio: false, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } } });
  } catch (e) { $('#eval-note').textContent = e.message; }
})();
