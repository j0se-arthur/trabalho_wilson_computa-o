'use strict';
(async () => {
  try {
    const s = await api('/api/stats');
    $('#k-images').textContent = s.images; $('#k-plates').textContent = s.plates; $('#k-rec').textContent = s.recognized;
    $('#k-time').textContent = s.images ? fmtMs(s.avgMillis) : '–';
    const d = await api('/api/analyses?limit=6');
    $('#recent').innerHTML = analysesTable(d.items);
  } catch (e) { $('#recent').innerHTML = `<p class="msg">${esc(e.message)}</p>`; }
})();
