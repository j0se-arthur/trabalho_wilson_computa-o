'use strict';
// Utilitários compartilhados por todas as páginas.
const $ = (s, r = document) => r.querySelector(s);
function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function fmtMs(ms) { return ms >= 1000 ? (ms / 1000).toFixed(2).replace('.', ',') + ' s' : Math.round(ms) + ' ms'; }
function fmtDate(iso) { const d = new Date(iso); return isNaN(d) ? iso : d.toLocaleString('pt-BR'); }
function pct(v) { return (v * 100).toFixed(1).replace('.', ',') + '%'; }
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), 3200); }
async function api(url, opts) {
  const r = await fetch(url, opts);
  let body = null;
  try { body = await r.json(); } catch (_) { /* resposta sem JSON */ }
  if (!r.ok) { const e = new Error((body && body.error) || ('Erro HTTP ' + r.status)); e.body = body; throw e; }
  return body;
}
function statusBadge(s) {
  const m = { concluido: ['ok', 'Concluído'], sem_placas: ['warn', 'Sem placas'], erro: ['err', 'Erro'], processando: ['warn', 'Processando'] }[s] || ['', s];
  return `<span class="badge ${m[0]}">${m[1]}</span>`;
}
function analysesTable(items) {
  if (!items.length) return '<p class="muted">Nenhuma análise encontrada.</p>';
  return `<table><thead><tr><th>#</th><th>Imagem</th><th>Data</th><th>Texto reconhecido</th><th>Placas</th><th>Tempo</th><th>Status</th></tr></thead><tbody>` +
    items.map(a => `<tr><td>${a.id}</td><td><a href="/analise/${a.id}">${esc(a.filename)}</a></td><td>${esc(fmtDate(a.processedAt))}</td><td class="wrap" dir="auto">${esc(a.texts || '—')}</td><td>${a.totalPlates}</td><td>${fmtMs(a.processingTime)}</td><td>${statusBadge(a.status)}</td></tr>`).join('') + '</tbody></table>';
}
document.addEventListener('DOMContentLoaded', () => {
  const page = document.body.dataset.page;
  document.querySelectorAll('nav a').forEach(a => { if (a.dataset.nav === page || (page === 'analise' && a.dataset.nav === 'historico')) a.classList.add('active'); });
  const modal = $('#modal');
  modal.addEventListener('click', () => { modal.hidden = true; });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') modal.hidden = true; });
  document.addEventListener('click', e => { const im = e.target.closest('figure img, .zoom'); if (im) { $('img', modal).src = im.src; modal.hidden = false; } });
});
