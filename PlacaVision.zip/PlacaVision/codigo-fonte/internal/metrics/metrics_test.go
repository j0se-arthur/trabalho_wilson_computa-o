package metrics

import (
	"image"
	"math"
	"testing"
)

func TestIoU(t *testing.T) {
	a := image.Rect(0, 0, 10, 10)
	if v := IoU(a, a); v != 1 {
		t.Fatalf("IoU idêntico = %v", v)
	}
	if v := IoU(a, image.Rect(20, 20, 30, 30)); v != 0 {
		t.Fatalf("IoU disjunto = %v", v)
	}
	if v := IoU(a, image.Rect(5, 0, 15, 10)); math.Abs(v-1.0/3) > 1e-9 {
		t.Fatalf("IoU metade = %v", v)
	}
}

func TestCER(t *testing.T) {
	cases := []struct {
		ref, hyp string
		want     float64
	}{
		{"1234", "1234", 0},
		{"1234", "1284", 0.25},
		{"1234", "123", 0.25},
		{"1234", "", 1},
		{"", "", 0},
		{"", "x", 1},
		{"٣٤٥٦", "٣٤٥٧", 0.25}, // dígitos árabes: contagem por caractere, não por byte
	}
	for _, c := range cases {
		if got := CER(c.ref, c.hyp); math.Abs(got-c.want) > 1e-9 {
			t.Errorf("CER(%q,%q)=%v, esperado %v", c.ref, c.hyp, got, c.want)
		}
	}
}

func TestEvaluateDetection(t *testing.T) {
	truth := []image.Rectangle{image.Rect(0, 0, 100, 40), image.Rect(200, 0, 300, 40)}
	pred := []image.Rectangle{image.Rect(2, 2, 98, 38), image.Rect(500, 500, 600, 540)}
	d := EvaluateDetection(pred, truth, 0.5)
	if d.TP != 1 || d.FP != 1 || d.FN != 1 {
		t.Fatalf("contagens inesperadas: %+v", d)
	}
	if d.Precision != 0.5 || d.Recall != 0.5 {
		t.Fatalf("precisão/recall inesperados: %+v", d)
	}
}
