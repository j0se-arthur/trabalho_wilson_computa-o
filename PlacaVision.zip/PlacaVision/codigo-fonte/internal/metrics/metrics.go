// Pacote metrics implementa as métricas de avaliação do sistema: IoU,
// precisão e recall da detecção e Character Error Rate (CER) do OCR.
package metrics

import "image"

// IoU calcula a interseção sobre a união de duas caixas.
func IoU(a, b image.Rectangle) float64 {
	i := a.Intersect(b)
	if i.Empty() {
		return 0
	}
	ia := float64(i.Dx() * i.Dy())
	ua := float64(a.Dx()*a.Dy()+b.Dx()*b.Dy()) - ia
	if ua <= 0 {
		return 0
	}
	return ia / ua
}

// Detection resume a comparação entre detecções e gabarito.
type Detection struct {
	TP, FP, FN int
	Precision  float64
	Recall     float64
	MeanIoU    float64 // média do IoU dos pares verdadeiros positivos
}

// EvaluateDetection compara caixas detectadas com as de referência usando
// correspondência gulosa por maior IoU; um par só conta se IoU >= thr.
func EvaluateDetection(pred, truth []image.Rectangle, thr float64) Detection {
	usedT := make([]bool, len(truth))
	var d Detection
	var sumIoU float64
	for _, p := range pred {
		best, bi := 0.0, -1
		for j, t := range truth {
			if usedT[j] {
				continue
			}
			if v := IoU(p, t); v > best {
				best, bi = v, j
			}
		}
		if bi >= 0 && best >= thr {
			usedT[bi] = true
			d.TP++
			sumIoU += best
		} else {
			d.FP++
		}
	}
	d.FN = len(truth) - d.TP
	if d.TP+d.FP > 0 {
		d.Precision = float64(d.TP) / float64(d.TP+d.FP)
	}
	if d.TP+d.FN > 0 {
		d.Recall = float64(d.TP) / float64(d.TP+d.FN)
	}
	if d.TP > 0 {
		d.MeanIoU = sumIoU / float64(d.TP)
	}
	return d
}

// Levenshtein devolve a distância de edição entre duas sequências de runas.
func Levenshtein(a, b []rune) int {
	prev := make([]int, len(b)+1)
	cur := make([]int, len(b)+1)
	for j := range prev {
		prev[j] = j
	}
	for i := 1; i <= len(a); i++ {
		cur[0] = i
		for j := 1; j <= len(b); j++ {
			cost := 1
			if a[i-1] == b[j-1] {
				cost = 0
			}
			cur[j] = min(prev[j]+1, cur[j-1]+1, prev[j-1]+cost)
		}
		prev, cur = cur, prev
	}
	return prev[len(b)]
}

// CER é a taxa de erro de caracteres: distância de edição / tamanho da referência.
// Não altera nem normaliza os textos; a comparação é exata, caractere a caractere.
func CER(reference, hypothesis string) float64 {
	r := []rune(reference)
	if len(r) == 0 {
		if len(hypothesis) == 0 {
			return 0
		}
		return 1
	}
	return float64(Levenshtein(r, []rune(hypothesis))) / float64(len(r))
}

// StripBidi remove apenas marcas invisíveis de direção do texto (LRM, RLM e
// controles de embutimento/isolamento), que o Tesseract costuma inserir em
// textos árabes. Nenhum outro caractere é alterado.
func StripBidi(s string) string {
	out := make([]rune, 0, len(s))
	for _, r := range s {
		switch {
		case r == 0x200E || r == 0x200F || r == 0x061C:
		case r >= 0x202A && r <= 0x202E:
		case r >= 0x2066 && r <= 0x2069:
		default:
			out = append(out, r)
		}
	}
	return string(out)
}
