package pdi

import "image"

// rank aplica máximo (dilatação) ou mínimo (erosão) com janela retangular
// kw x kh, de forma separável.
func rank(g *Gray, kw, kh int, isMax bool) *Gray {
	rx, ry := kw/2, kh/2
	tmp := NewGray(g.W, g.H)
	for y := 0; y < g.H; y++ {
		for x := 0; x < g.W; x++ {
			best := g.At(x, y)
			for i := -rx; i <= rx; i++ {
				v := g.At(x+i, y)
				if (isMax && v > best) || (!isMax && v < best) {
					best = v
				}
			}
			tmp.Pix[y*g.W+x] = best
		}
	}
	out := NewGray(g.W, g.H)
	for y := 0; y < g.H; y++ {
		for x := 0; x < g.W; x++ {
			best := tmp.At(x, y)
			for j := -ry; j <= ry; j++ {
				v := tmp.At(x, y+j)
				if (isMax && v > best) || (!isMax && v < best) {
					best = v
				}
			}
			out.Pix[y*g.W+x] = best
		}
	}
	return out
}

// Dilate expande regiões claras.
func Dilate(g *Gray, kw, kh int) *Gray { return rank(g, kw, kh, true) }

// Erode contrai regiões claras.
func Erode(g *Gray, kw, kh int) *Gray { return rank(g, kw, kh, false) }

// Close (fechamento) = dilatação seguida de erosão: une regiões próximas.
func Close(g *Gray, kw, kh int) *Gray { return Erode(Dilate(g, kw, kh), kw, kh) }

// Open (abertura) = erosão seguida de dilatação: remove ruído pequeno.
func Open(g *Gray, kw, kh int) *Gray { return Dilate(Erode(g, kw, kh), kw, kh) }

// Pt é um ponto com coordenadas reais.
type Pt struct{ X, Y float64 }

// Component é uma região conexa de uma imagem binária.
type Component struct {
	Box  image.Rectangle
	Area int
	// Cantos extremos do componente: superior-esq., superior-dir., inferior-dir., inferior-esq.
	TL, TR, BR, BL Pt
}

// Components rotula as regiões conexas (8-vizinhança) de pixels > 0.
func Components(bin *Gray) []Component {
	w, h := bin.W, bin.H
	seen := make([]bool, w*h)
	var out []Component
	var stack []int
	for start := 0; start < w*h; start++ {
		if bin.Pix[start] == 0 || seen[start] {
			continue
		}
		seen[start] = true
		stack = append(stack[:0], start)
		sx, sy := start%w, start/w
		c := Component{Box: image.Rect(sx, sy, sx+1, sy+1)}
		minS, maxS, minD, maxD := 1<<30, -(1 << 30), 1<<30, -(1 << 30)
		for len(stack) > 0 {
			p := stack[len(stack)-1]
			stack = stack[:len(stack)-1]
			x, y := p%w, p/w
			c.Area++
			if x < c.Box.Min.X {
				c.Box.Min.X = x
			}
			if y < c.Box.Min.Y {
				c.Box.Min.Y = y
			}
			if x+1 > c.Box.Max.X {
				c.Box.Max.X = x + 1
			}
			if y+1 > c.Box.Max.Y {
				c.Box.Max.Y = y + 1
			}
			if s := x + y; s < minS {
				minS, c.TL = s, Pt{float64(x), float64(y)}
			}
			if s := x + y; s > maxS {
				maxS, c.BR = s, Pt{float64(x + 1), float64(y + 1)}
			}
			if d := x - y; d < minD {
				minD, c.BL = d, Pt{float64(x), float64(y + 1)}
			}
			if d := x - y; d > maxD {
				maxD, c.TR = d, Pt{float64(x + 1), float64(y)}
			}
			for dy := -1; dy <= 1; dy++ {
				for dx := -1; dx <= 1; dx++ {
					nx, ny := x+dx, y+dy
					if nx < 0 || ny < 0 || nx >= w || ny >= h {
						continue
					}
					q := ny*w + nx
					if bin.Pix[q] != 0 && !seen[q] {
						seen[q] = true
						stack = append(stack, q)
					}
				}
			}
		}
		out = append(out, c)
	}
	return out
}
