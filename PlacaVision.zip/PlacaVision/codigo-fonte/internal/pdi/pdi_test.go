package pdi

import (
	"image"
	"image/color"
	"image/draw"
	"math"
	"os"
	"path/filepath"
	"testing"
)

func TestGrayConversion(t *testing.T) {
	im := image.NewRGBA(image.Rect(0, 0, 2, 1))
	im.SetRGBA(0, 0, color.RGBA{255, 255, 255, 255})
	im.SetRGBA(1, 0, color.RGBA{255, 0, 0, 255})
	g := GrayFromRGBA(im)
	if g.Pix[0] != 255 || g.Pix[1] != 76 { // 0,299*255 ≈ 76
		t.Fatalf("cinza incorreto: %v", g.Pix)
	}
}

func TestGaussianPreservesConstantAndSmoothsImpulse(t *testing.T) {
	g := NewGray(15, 15)
	for i := range g.Pix {
		g.Pix[i] = 100
	}
	if out := Gaussian(g, 5, 1); out.Pix[7*15+7] != 100 {
		t.Fatalf("imagem constante deve permanecer constante")
	}
	g = NewGray(15, 15)
	g.Pix[7*15+7] = 255
	out := Gaussian(g, 5, 1)
	if out.Pix[7*15+7] >= 255 || out.Pix[7*15+8] == 0 {
		t.Fatalf("impulso deveria ser espalhado")
	}
}

func TestBilateralKeepsEdge(t *testing.T) {
	g := NewGray(20, 10)
	for y := 0; y < 10; y++ {
		for x := 10; x < 20; x++ {
			g.Pix[y*20+x] = 200
		}
	}
	out := Bilateral(g, 3, 3, 30)
	if out.Pix[5*20+9] > 5 || out.Pix[5*20+10] < 195 {
		t.Fatalf("a borda deveria ser preservada: %d %d", out.Pix[5*20+9], out.Pix[5*20+10])
	}
}

func TestEqualizeHistStretchesContrast(t *testing.T) {
	g := NewGray(10, 10)
	for i := range g.Pix {
		g.Pix[i] = uint8(100 + i%20)
	}
	out := EqualizeHist(g)
	lo, hi := uint8(255), uint8(0)
	for _, v := range out.Pix {
		lo, hi = min(lo, v), max(hi, v)
	}
	if lo != 0 || hi != 255 {
		t.Fatalf("faixa após equalização = [%d,%d]", lo, hi)
	}
}

func TestOtsuSeparatesTwoLevels(t *testing.T) {
	g := NewGray(10, 10)
	for i := range g.Pix {
		if i%2 == 0 {
			g.Pix[i] = 40
		} else {
			g.Pix[i] = 200
		}
	}
	if th := Otsu(g); th < 40 || th >= 200 {
		t.Fatalf("limiar de Otsu = %d", th)
	}
}

func TestAdaptiveThresholdDetectsDarkTextOnGradient(t *testing.T) {
	g := NewGray(100, 40)
	for y := 0; y < 40; y++ {
		for x := 0; x < 100; x++ {
			g.Pix[y*100+x] = uint8(100 + x) // fundo com gradiente
		}
	}
	for y := 15; y < 25; y++ {
		g.Pix[y*100+50] = 20 // traço escuro
	}
	out := AdaptiveThreshold(g, 21, 10)
	if out.Pix[20*100+50] != 0 || out.Pix[5*100+50] != 255 {
		t.Fatalf("limiarização adaptativa falhou")
	}
}

func TestSobelFindsVerticalEdge(t *testing.T) {
	g := NewGray(20, 20)
	for y := 0; y < 20; y++ {
		for x := 10; x < 20; x++ {
			g.Pix[y*20+x] = 255
		}
	}
	gx, _ := Sobel(g)
	if gx.Pix[10*20+10] < 100 || gx.Pix[10*20+3] != 0 {
		t.Fatalf("Sobel não detectou a borda vertical")
	}
}

func TestMorphologyAndComponents(t *testing.T) {
	g := NewGray(30, 10)
	for _, x := range []int{5, 8, 11} { // três traços verticais separados
		for y := 2; y < 8; y++ {
			g.Pix[y*30+x] = 255
		}
	}
	if n := len(Components(g)); n != 3 {
		t.Fatalf("esperava 3 componentes, obtive %d", n)
	}
	closed := Close(g, 5, 1)
	comps := Components(closed)
	if len(comps) != 1 || comps[0].Box.Dx() < 7 {
		t.Fatalf("o fechamento deveria unir os traços: %+v", comps)
	}
	if opened := Open(g, 3, 3); len(Components(opened)) != 0 {
		t.Fatalf("a abertura deveria remover traços de 1 px")
	}
}

func TestHomographyIdentityAndWarp(t *testing.T) {
	q := [4]Pt{{0, 0}, {100, 0}, {100, 40}, {0, 40}}
	h, ok := homography(q, q)
	if !ok || math.Abs(h[0]-1) > 1e-9 || math.Abs(h[4]-1) > 1e-9 {
		t.Fatalf("homografia identidade incorreta: %v", h)
	}
	src := image.NewRGBA(image.Rect(0, 0, 200, 100))
	draw.Draw(src, src.Bounds(), image.NewUniform(color.RGBA{10, 10, 10, 255}), image.Point{}, draw.Src)
	draw.Draw(src, image.Rect(50, 30, 150, 70), image.NewUniform(color.RGBA{250, 250, 250, 255}), image.Point{}, draw.Src)
	out := WarpPerspective(src, [4]Pt{{50, 30}, {150, 30}, {150, 70}, {50, 70}}, 100, 40)
	if c := out.RGBAAt(50, 20); c.R < 240 {
		t.Fatalf("a região retificada deveria ser clara, obtive %v", c)
	}
}

func TestAnalyzeQuad(t *testing.T) {
	box := image.Rect(0, 0, 120, 40)
	if i := AnalyzeQuad([4]Pt{{0, 0}, {120, 0}, {120, 40}, {0, 40}}, box); i.Reliable {
		t.Fatalf("retângulo alinhado não precisa de perspectiva: %+v", i)
	}
	if i := AnalyzeQuad([4]Pt{{0, 6}, {120, 0}, {120, 34}, {0, 40}}, box); !i.Reliable {
		t.Fatalf("quadrilátero inclinado coerente deveria ser aceito: %+v", i)
	}
	if i := AnalyzeQuad([4]Pt{{0, 0}, {120, 0}, {30, 40}, {0, 40}}, box); i.Reliable {
		t.Fatalf("quadrilátero incoerente deveria ser rejeitado")
	}
}

func TestEvaluateRejectsNonPlateShapes(t *testing.T) {
	edges := NewGray(400, 300)
	for y := 100; y < 160; y++ { // quadrado: proporção 1:1 e sem traços
		for x := 100; x < 160; x++ {
			edges.Pix[y*400+x] = 255
		}
	}
	ref := NewGray(400, 300)
	cands := EvaluateComponents(Components(edges), edges, ref)
	for _, c := range cands {
		if c.Accepted {
			t.Fatalf("um quadrado não deve ser aceito como placa: %+v", c)
		}
	}
}

func TestIoU(t *testing.T) {
	a := image.Rect(0, 0, 10, 10)
	if IoU(a, a) != 1 || IoU(a, image.Rect(10, 0, 20, 10)) != 0 {
		t.Fatalf("IoU incorreto")
	}
}

func loadExample(t *testing.T, name string) image.Image {
	t.Helper()
	f, err := os.Open(filepath.Join("..", "..", "web", "static", "exemplos", name))
	if err != nil {
		t.Skip("imagem de exemplo indisponível:", err)
	}
	defer f.Close()
	img, _, err := image.Decode(f)
	if err != nil {
		t.Fatal(err)
	}
	return img
}

func init() { registerDecoders() }

func TestPipelineOnExamples(t *testing.T) {
	// Os exemplos são imagens sintéticas (não fotos reais): servem como teste de
	// regressão do pipeline, não como medida de desempenho em imagens reais.
	cases := []struct {
		file    string
		minPlat int
		maxPlat int
	}{
		{"frontal.jpg", 1, 3},
		{"inclinada.jpg", 1, 3},
		{"pouca_luz.jpg", 1, 3},
		{"baixa_resolucao.jpg", 1, 3},
		{"dois_carros.jpg", 2, 4},
		{"sem_placa.jpg", 0, 0},
	}
	for _, c := range cases {
		t.Run(c.file, func(t *testing.T) {
			res, err := Process(loadExample(t, c.file), t.TempDir())
			if err != nil {
				t.Fatalf("erro no pipeline: %v", err)
			}
			if n := len(res.Plates); n < c.minPlat || n > c.maxPlat {
				t.Fatalf("%d placas detectadas; esperado entre %d e %d", n, c.minPlat, c.maxPlat)
			}
			for _, s := range res.Steps {
				if s.Status != "ok" {
					t.Fatalf("etapa %s falhou: %s", s.Name, s.Detail)
				}
			}
			for _, p := range res.Plates {
				if len(p.OCRFiles) != 3 || p.CropFile == "" {
					t.Fatalf("a placa %d deveria ter recorte e 3 versões para OCR: %+v", p.Index, p)
				}
			}
		})
	}
}

func TestPipelineFrontalPlateLocation(t *testing.T) {
	res, err := Process(loadExample(t, "frontal.jpg"), t.TempDir())
	if err != nil || len(res.Plates) == 0 {
		t.Fatalf("sem placas: %v", err)
	}
	truth := image.Rect(480, 530, 800, 640) // região real da placa na imagem sintética (1280x853)
	best := 0.0
	for _, p := range res.Plates {
		best = math.Max(best, IoU(image.Rect(p.X, p.Y, p.X+p.W, p.Y+p.H), truth))
	}
	if best < 0.5 {
		t.Fatalf("IoU da melhor detecção = %.2f (< 0,5)", best)
	}
}

func TestPipelineTinyImageDoesNotPanic(t *testing.T) {
	res, err := Process(image.NewRGBA(image.Rect(0, 0, 8, 8)), t.TempDir())
	if res == nil {
		t.Fatalf("o pipeline deveria devolver resultado mesmo sem placas (err=%v)", err)
	}
}

func TestEnhancePlateProducesDarkTextOnLight(t *testing.T) {
	crop := image.NewRGBA(image.Rect(0, 0, 200, 60))
	draw.Draw(crop, crop.Bounds(), image.NewUniform(color.RGBA{230, 230, 220, 255}), image.Point{}, draw.Src)
	for _, x := range []int{40, 60, 80, 100, 120, 140} {
		draw.Draw(crop, image.Rect(x, 15, x+8, 45), image.NewUniform(color.RGBA{10, 10, 10, 255}), image.Point{}, draw.Src)
	}
	v := EnhancePlate(crop)
	for name, g := range map[string]*Gray{"otsu": v.Otsu, "adaptativa": v.Adaptive} {
		if Mean(g) < 160 {
			t.Errorf("%s: fundo deveria ser predominantemente claro (média %.0f)", name, Mean(g))
		}
		if g.H != plateHeight+32 {
			t.Errorf("%s: altura %d, esperado %d", name, g.H, plateHeight+32)
		}
	}
}
