package pdi

import "image"

// PlateVersions reúne as versões tratadas da placa recortada.
type PlateVersions struct {
	Gray      *Gray // cinza ampliado e suavizado
	Equalized *Gray // contraste equalizado
	Otsu      *Gray // binarização de Otsu (texto escuro, fundo claro)
	Adaptive  *Gray // limiarização adaptativa + morfologia
}

const plateHeight = 160

// EnhancePlate aplica a melhoria da placa: cinza, redimensionamento, redução de
// ruído, normalização de contraste, binarização (Otsu e adaptativa), remoção de
// molduras e operações morfológicas.
func EnhancePlate(crop *image.RGBA) PlateVersions {
	g := GrayFromRGBA(crop)
	nw := g.W * plateHeight / max(g.H, 1)
	nw = min(max(nw, 40), 1400)
	g = ResizeGray(g, nw, plateHeight)
	g = Gaussian(g, 5, 1.2)
	norm := Normalize(g, 0.02, 0.98)
	var v PlateVersions
	v.Gray = AddBorder(norm, 16, uint8(Mean(norm)))
	eq := EqualizeHist(g)
	v.Equalized = AddBorder(eq, 16, uint8(Mean(eq)))

	otsu := textDark(Threshold(norm, Otsu(norm), false))
	v.Otsu = AddBorder(Invert(removeFrame(cleanMask(Invert(otsu)))), 16, 255)

	ad := textDark(AdaptiveThreshold(norm, 51, 12))
	v.Adaptive = AddBorder(Invert(removeFrame(cleanMask(Invert(ad)))), 16, 255)
	return v
}

// Normalize estica o contraste entre os percentis lo e hi do histograma.
func Normalize(g *Gray, lo, hi float64) *Gray {
	var hist [256]int
	for _, v := range g.Pix {
		hist[v]++
	}
	n := len(g.Pix)
	pl, ph, acc := 0, 255, 0
	for i := 0; i < 256; i++ {
		acc += hist[i]
		if float64(acc) >= lo*float64(n) {
			pl = i
			break
		}
	}
	acc = 0
	for i := 0; i < 256; i++ {
		acc += hist[i]
		if float64(acc) >= hi*float64(n) {
			ph = i
			break
		}
	}
	out := NewGray(g.W, g.H)
	if ph <= pl {
		copy(out.Pix, g.Pix)
		return out
	}
	for i, v := range g.Pix {
		out.Pix[i] = clamp8(float64(int(v)-pl) * 255 / float64(ph-pl))
	}
	return out
}

// textDark garante texto escuro sobre fundo claro (preferência do Tesseract):
// se a maioria dos pixels for escura, inverte.
func textDark(b *Gray) *Gray {
	if Mean(b) < 127 {
		return Invert(b)
	}
	return b
}

// cleanMask remove ruído pontual da máscara do texto (255 = texto) com
// abertura e fechamento morfológicos.
func cleanMask(mask *Gray) *Gray {
	mask = Open(mask, 3, 3)
	return Close(mask, 3, 3)
}

// removeFrame apaga da máscara linhas e colunas externas quase totalmente
// escuras (moldura da placa, para-choque, sombra), que não são caracteres.
func removeFrame(mask *Gray) *Gray {
	out := mask.Clone()
	for y := 0; y < mask.H; y++ {
		on := 0
		for x := 0; x < mask.W; x++ {
			if mask.Pix[y*mask.W+x] != 0 {
				on++
			}
		}
		if float64(on) >= 0.7*float64(mask.W) {
			for x := 0; x < mask.W; x++ {
				out.Pix[y*mask.W+x] = 0
			}
		}
	}
	edge := mask.W / 10
	for x := 0; x < mask.W; x++ {
		if x >= edge && x < mask.W-edge {
			continue
		}
		on := 0
		for y := 0; y < mask.H; y++ {
			if out.Pix[y*mask.W+x] != 0 {
				on++
			}
		}
		if float64(on) >= 0.7*float64(mask.H) {
			for y := 0; y < mask.H; y++ {
				out.Pix[y*mask.W+x] = 0
			}
		}
	}
	// remove blocos escuros grandes que tocam a borda sem a altura de um caractere
	for _, c := range Components(out) {
		touches := c.Box.Min.X == 0 || c.Box.Max.X == mask.W || c.Box.Max.Y == mask.H || c.Box.Min.Y == 0
		if touches && (c.Box.Dy() < mask.H/4 || c.Box.Dx() < mask.W/60) && c.Area < mask.W*mask.H/40 {
			for y := c.Box.Min.Y; y < c.Box.Max.Y; y++ {
				for x := c.Box.Min.X; x < c.Box.Max.X; x++ {
					out.Pix[y*mask.W+x] = 0
				}
			}
		}
	}
	return out
}
