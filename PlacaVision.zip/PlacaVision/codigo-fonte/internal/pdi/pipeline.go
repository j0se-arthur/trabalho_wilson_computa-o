package pdi

import (
	"fmt"
	"image"
	"image/color"
	"math"
	"os"
	"path/filepath"
	"time"
)

// Step registra uma etapa do pipeline (nome, imagem gerada e tempo gasto).
type Step struct {
	Name   string  `json:"name"`
	Title  string  `json:"title"`
	File   string  `json:"file"`
	Millis float64 `json:"millis"`
	Status string  `json:"status"` // ok | erro
	Detail string  `json:"detail"`
}

// PlateResult descreve uma placa localizada (coordenadas na imagem original).
type PlateResult struct {
	Index    int      `json:"index"`
	X        int      `json:"x"`
	Y        int      `json:"y"`
	W        int      `json:"w"`
	H        int      `json:"h"`
	Score    float64  `json:"score"`
	Method   string   `json:"method"` // perspectiva | recorte
	Note     string   `json:"note"`
	CropFile string   `json:"cropFile"`
	OCRFiles []string `json:"ocrFiles"` // versões para o OCR (equalizada, otsu, adaptativa)
}

// Result é o retorno completo do processamento.
type Result struct {
	Width    int           `json:"width"`
	Height   int           `json:"height"`
	Channels int           `json:"channels"`
	Steps    []Step        `json:"steps"`
	Plates   []PlateResult `json:"plates"`
	Total    time.Duration `json:"-"`
}

type runner struct {
	res *Result
	dir string
	idx int
}

// step executa uma etapa isolando pânicos, medindo o tempo e salvando a imagem.
func (r *runner) step(name, title string, fn func() (image.Image, string)) (ok bool) {
	st := Step{Name: name, Title: title, Status: "ok"}
	t0 := time.Now()
	defer func() {
		if rec := recover(); rec != nil {
			st.Status, st.Detail, ok = "erro", fmt.Sprint("falha interna: ", rec), false
		}
		st.Millis = float64(time.Since(t0).Microseconds()) / 1000
		r.res.Steps = append(r.res.Steps, st)
	}()
	img, detail := fn()
	st.Detail = detail
	if img != nil {
		r.idx++
		st.File = fmt.Sprintf("%02d_%s.png", r.idx, name)
		if err := SavePNG(filepath.Join(r.dir, st.File), img); err != nil {
			st.Status, st.Detail, st.File = "erro", "não foi possível salvar a imagem: "+err.Error(), ""
			return false
		}
	}
	return true
}

func countChannels(img image.Image) int {
	switch img.(type) {
	case *image.Gray, *image.Gray16:
		return 1
	}
	if o, ok := img.(interface{ Opaque() bool }); ok && !o.Opaque() {
		return 4
	}
	return 3
}

const workWidth = 960

func stretch(g *Gray) *Gray {
	m := uint8(1)
	for _, v := range g.Pix {
		if v > m {
			m = v
		}
	}
	out := NewGray(g.W, g.H)
	for i, v := range g.Pix {
		out.Pix[i] = uint8(int(v) * 255 / int(m))
	}
	return out
}

// Process executa o pipeline completo (etapas 1 a 6 do projeto) e grava as
// imagens intermediárias em outDir. O OCR é feito depois, sobre OCRFiles.
func Process(src image.Image, outDir string) (*Result, error) {
	t0 := time.Now()
	if err := os.MkdirAll(outDir, 0o755); err != nil {
		return nil, err
	}
	b := src.Bounds()
	res := &Result{Width: b.Dx(), Height: b.Dy(), Channels: countChannels(src)}
	r := &runner{res: res, dir: outDir}
	defer func() { res.Total = time.Since(t0) }()

	var orig, work *image.RGBA
	var gray, gauss, bil, eq, gx, edges, morph *Gray
	var scale float64

	// ETAPA 1 – aquisição
	if !r.step("original", "Imagem original", func() (image.Image, string) {
		orig = ToRGBA(src)
		scale = 1
		nw, nh := orig.Bounds().Dx(), orig.Bounds().Dy()
		if nw > workWidth {
			scale = float64(nw) / workWidth
			nh = int(math.Round(float64(nh) / scale))
			nw = workWidth
		}
		work = ResizeRGBA(orig, nw, nh)
		return work, fmt.Sprintf("%dx%d px, %d canal(is); processada em %dx%d", res.Width, res.Height, res.Channels, nw, nh)
	}) {
		return res, fmt.Errorf("falha na aquisição da imagem")
	}
	// ETAPA 2 – pré-processamento
	if !r.step("cinza", "Escala de cinza", func() (image.Image, string) {
		gray = GrayFromRGBA(work)
		return gray.ToImage(), "luminância ITU-R 601"
	}) {
		return res, fmt.Errorf("falha na conversão para cinza")
	}
	if !r.step("gaussiano", "Filtro gaussiano 5x5", func() (image.Image, string) {
		gauss = Gaussian(gray, 5, 1.0)
		return gauss.ToImage(), "σ = 1,0"
	}) {
		return res, fmt.Errorf("falha no filtro gaussiano")
	}
	if !r.step("bilateral", "Filtro bilateral", func() (image.Image, string) {
		bil = Bilateral(gauss, 3, 3, 30)
		return bil.ToImage(), "raio 3, σ espacial 3, σ de intensidade 30"
	}) {
		return res, fmt.Errorf("falha no filtro bilateral")
	}
	if !r.step("equalizada", "Equalização de histograma", func() (image.Image, string) {
		eq = EqualizeHist(bil)
		return eq.ToImage(), "contraste global"
	}) {
		return res, fmt.Errorf("falha na equalização")
	}
	r.step("limiar_adaptativo", "Limiarização adaptativa", func() (image.Image, string) {
		return AdaptiveThreshold(eq, 31, 8).ToImage(), "janela 31x31 (apenas para visualização)"
	})
	// ETAPA 3 – bordas e morfologia
	if !r.step("sobel", "Gradiente de Sobel (bordas verticais)", func() (image.Image, string) {
		gx, _ = Sobel(eq)
		return stretch(gx).ToImage(), "|Gx| realça as bordas verticais dos caracteres"
	}) {
		return res, fmt.Errorf("falha na detecção de bordas")
	}
	if !r.step("bordas", "Binarização das bordas (Otsu)", func() (image.Image, string) {
		t := max(Otsu(gx), 15)
		edges = Threshold(gx, t, false)
		return edges.ToImage(), fmt.Sprintf("limiar %d", t)
	}) {
		return res, fmt.Errorf("falha na binarização das bordas")
	}
	if !r.step("morfologia", "Fechamento e abertura morfológicos", func() (image.Image, string) {
		kw := (work.Bounds().Dx() / 40) | 1
		morph = Close(edges, kw, 11)
		morph = Open(morph, 7, 5)
		return morph.ToImage(), fmt.Sprintf("fechamento %dx11, abertura 7x5", kw)
	}) {
		return res, fmt.Errorf("falha nas operações morfológicas")
	}
	// ETAPA 3/4 – contornos e seleção
	var cands, sel []Candidate
	if !r.step("contornos", "Contornos avaliados", func() (image.Image, string) {
		cands = EvaluateComponents(Components(morph), edges, bil)
		sel = SelectPlates(cands, morph.Bounds())
		vis := GrayToRGBA(morph)
		for _, c := range cands {
			col := color.RGBA{200, 60, 60, 255}
			if c.Accepted {
				col = color.RGBA{240, 200, 40, 255}
			}
			DrawRect(vis, c.Box, col, 1)
		}
		for _, c := range sel {
			DrawRect(vis, c.Box, color.RGBA{40, 220, 120, 255}, 3)
		}
		return vis, fmt.Sprintf("%d regiões avaliadas; %d aceitas; %d selecionadas (vermelho=rejeitada, amarelo=aceita, verde=selecionada)", len(cands), countAccepted(cands), len(sel))
	}) {
		return res, fmt.Errorf("falha na análise de contornos")
	}
	// ETAPA 4 – detecção
	r.step("deteccao", "Placas detectadas", func() (image.Image, string) {
		vis := ToRGBA(work)
		for i, c := range sel {
			DrawRect(vis, c.Box, color.RGBA{40, 220, 120, 255}, 3)
			drawNumber(vis, i+1, c.Box.Min.X+4, max(c.Box.Min.Y-22, 2))
		}
		if len(sel) == 0 {
			return vis, "nenhuma placa encontrada"
		}
		return vis, fmt.Sprintf("%d placa(s) localizada(s)", len(sel))
	})

	// ETAPAS 5 e 6 – recorte, perspectiva e melhoria, por placa
	for i, c := range sel {
		n := i + 1
		pr := PlateResult{Index: n, Score: math.Round(c.Score*1000) / 1000}
		box := scaleRect(c.Box, scale).Intersect(orig.Bounds())
		pr.X, pr.Y, pr.W, pr.H = box.Min.X, box.Min.Y, box.Dx(), box.Dy()

		var crop *image.RGBA
		cname := fmt.Sprintf("placa%d_recorte", n)
		ok := r.step(cname, fmt.Sprintf("Placa %d – recorte", n), func() (image.Image, string) {
			info := AnalyzeQuad(c.Corners, c.Box)
			if info.Reliable {
				q := expandQuad(c.Corners, 0.04)
				for k := range q {
					q[k] = Pt{q[k].X * scale, q[k].Y * scale}
				}
				crop = WarpPerspective(orig, q, int(float64(info.OutW)*scale*1.08), int(float64(info.OutH)*scale*1.08))
				pr.Method, pr.Note = "perspectiva", fmt.Sprintf("homografia aplicada (inclinação %.1f°)", info.Angle)
			} else {
				padX, padY := box.Dx()/25, box.Dy()/12
				crop = CropRGBA(orig, image.Rect(box.Min.X-padX, box.Min.Y-padY, box.Max.X+padX, box.Max.Y+padY))
				pr.Method, pr.Note = "recorte", "recorte convencional: "+info.Reason
			}
			return crop, pr.Note
		})
		if !ok || crop == nil || crop.Bounds().Empty() {
			continue
		}
		pr.CropFile = res.Steps[len(res.Steps)-1].File
		var v PlateVersions
		okE := r.step(fmt.Sprintf("placa%d_cinza", n), fmt.Sprintf("Placa %d – cinza suavizada e normalizada", n), func() (image.Image, string) {
			v = EnhancePlate(crop)
			return v.Gray.ToImage(), fmt.Sprintf("altura %d px, gaussiano 5x5 e contraste normalizado (2%%–98%%)", plateHeight)
		})
		cinzaIdx := len(res.Steps) - 1
		if okE {
			save := func(name, title string, g *Gray, detail string) {
				r.step(fmt.Sprintf("placa%d_%s", n, name), fmt.Sprintf("Placa %d – %s", n, title), func() (image.Image, string) {
					return g.ToImage(), detail
				})
				pr.OCRFiles = append(pr.OCRFiles, res.Steps[len(res.Steps)-1].File)
			}
			r.step(fmt.Sprintf("placa%d_equalizada", n), fmt.Sprintf("Placa %d – equalizada", n), func() (image.Image, string) {
				return v.Equalized.ToImage(), "equalização de histograma (visualização)"
			})
			pr.OCRFiles = append([]string{res.Steps[cinzaIdx].File}, pr.OCRFiles...)
			save("otsu", "binarização de Otsu", v.Otsu, "Otsu + abertura/fechamento morfológicos")
			save("adaptativa", "limiarização adaptativa", v.Adaptive, "janela 41x41 + morfologia")
		}
		res.Plates = append(res.Plates, pr)
	}
	return res, nil
}

func countAccepted(c []Candidate) (n int) {
	for _, x := range c {
		if x.Accepted {
			n++
		}
	}
	return
}

func scaleRect(r image.Rectangle, s float64) image.Rectangle {
	return image.Rect(int(float64(r.Min.X)*s), int(float64(r.Min.Y)*s), int(math.Ceil(float64(r.Max.X)*s)), int(math.Ceil(float64(r.Max.Y)*s)))
}

// expandQuad afasta os vértices do centro (fração f) para incluir uma pequena margem.
func expandQuad(q [4]Pt, f float64) [4]Pt {
	cx, cy := (q[0].X+q[1].X+q[2].X+q[3].X)/4, (q[0].Y+q[1].Y+q[2].Y+q[3].Y)/4
	var o [4]Pt
	for i, p := range q {
		o[i] = Pt{p.X + (p.X-cx)*f, p.Y + (p.Y-cy)*f}
	}
	return o
}

var digitFont = [10][5]uint8{
	{7, 5, 5, 5, 7}, {2, 6, 2, 2, 7}, {7, 1, 7, 4, 7}, {7, 1, 7, 1, 7}, {5, 5, 7, 1, 1},
	{7, 4, 7, 1, 7}, {7, 4, 7, 5, 7}, {7, 1, 1, 1, 1}, {7, 5, 7, 5, 7}, {7, 5, 7, 1, 7},
}

// drawNumber desenha um dígito (1-9) com uma fonte bitmap 3x5 ampliada.
func drawNumber(img *image.RGBA, n, x, y int) {
	if n < 0 || n > 9 {
		return
	}
	const s = 4
	for r := 0; r < 5; r++ {
		for c := 0; c < 3; c++ {
			if digitFont[n][r]&(1<<(2-c)) != 0 {
				for dy := 0; dy < s; dy++ {
					for dx := 0; dx < s; dx++ {
						setPx(img, x+c*s+dx, y+r*s+dy, color.RGBA{40, 220, 120, 255})
					}
				}
			}
		}
	}
}
