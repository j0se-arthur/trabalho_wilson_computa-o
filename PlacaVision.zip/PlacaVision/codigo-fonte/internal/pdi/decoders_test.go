package pdi

import _ "image/jpeg"

func registerDecoders() {}
