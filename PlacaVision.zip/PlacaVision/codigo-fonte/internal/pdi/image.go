// Pacote pdi implementa, em Go puro, as operações de Processamento Digital
// de Imagens usadas pelo sistema (filtros, bordas, morfologia, detecção etc.).
package pdi

import (
	"image"
	"image/color"
	"image/draw"
	"image/png"
	"math"
	"os"
)

// Gray é uma imagem em tons de cinza de 8 bits, com acesso direto aos pixels.
type Gray struct {
	W, H int
	Pix  []uint8
}

func NewGray(w, h int) *Gray { return &Gray{W: w, H: h, Pix: make([]uint8, w*h)} }

// At devolve o pixel com coordenadas limitadas às bordas (replicação de borda).
func (g *Gray) At(x, y int) uint8 {
	if x < 0 {
		x = 0
	} else if x >= g.W {
		x = g.W - 1
	}
	if y < 0 {
		y = 0
	} else if y >= g.H {
		y = g.H - 1
	}
	return g.Pix[y*g.W+x]
}

// Bounds devolve o retângulo da imagem.
func (g *Gray) Bounds() image.Rectangle { return image.Rect(0, 0, g.W, g.H) }

func (g *Gray) Clone() *Gray {
	c := NewGray(g.W, g.H)
	copy(c.Pix, g.Pix)
	return c
}

func (g *Gray) ToImage() *image.Gray {
	im := image.NewGray(image.Rect(0, 0, g.W, g.H))
	copy(im.Pix, g.Pix)
	return im
}

// ToRGBA converte qualquer image.Image para *image.RGBA (cópia).
func ToRGBA(img image.Image) *image.RGBA {
	b := img.Bounds()
	out := image.NewRGBA(image.Rect(0, 0, b.Dx(), b.Dy()))
	draw.Draw(out, out.Bounds(), img, b.Min, draw.Src)
	return out
}

// GrayFromRGBA converte para escala de cinza usando a luminância ITU-R 601.
func GrayFromRGBA(src *image.RGBA) *Gray {
	w, h := src.Bounds().Dx(), src.Bounds().Dy()
	g := NewGray(w, h)
	for y := 0; y < h; y++ {
		row := src.Pix[y*src.Stride : y*src.Stride+w*4]
		for x := 0; x < w; x++ {
			r, gg, b := uint32(row[x*4]), uint32(row[x*4+1]), uint32(row[x*4+2])
			g.Pix[y*w+x] = uint8((299*r + 587*gg + 114*b + 500) / 1000)
		}
	}
	return g
}

// GrayToRGBA converte tons de cinza para RGBA (para desenhar em cores).
func GrayToRGBA(g *Gray) *image.RGBA {
	out := image.NewRGBA(image.Rect(0, 0, g.W, g.H))
	for i, v := range g.Pix {
		out.Pix[i*4], out.Pix[i*4+1], out.Pix[i*4+2], out.Pix[i*4+3] = v, v, v, 255
	}
	return out
}

// ResizeRGBA redimensiona: média de área ao reduzir, bilinear ao ampliar.
func ResizeRGBA(src *image.RGBA, nw, nh int) *image.RGBA {
	sw, sh := src.Bounds().Dx(), src.Bounds().Dy()
	dst := image.NewRGBA(image.Rect(0, 0, nw, nh))
	if nw == sw && nh == sh {
		copy(dst.Pix, src.Pix)
		return dst
	}
	xr, yr := float64(sw)/float64(nw), float64(sh)/float64(nh)
	for y := 0; y < nh; y++ {
		for x := 0; x < nw; x++ {
			var r, g, b, a float64
			if xr > 1 || yr > 1 { // redução: média da caixa
				x0, x1 := int(float64(x)*xr), int(math.Ceil(float64(x+1)*xr))
				y0, y1 := int(float64(y)*yr), int(math.Ceil(float64(y+1)*yr))
				if x1 > sw {
					x1 = sw
				}
				if y1 > sh {
					y1 = sh
				}
				if x1 <= x0 {
					x1 = x0 + 1
				}
				if y1 <= y0 {
					y1 = y0 + 1
				}
				n := float64((x1 - x0) * (y1 - y0))
				for yy := y0; yy < y1; yy++ {
					for xx := x0; xx < x1; xx++ {
						o := yy*src.Stride + xx*4
						r += float64(src.Pix[o])
						g += float64(src.Pix[o+1])
						b += float64(src.Pix[o+2])
						a += float64(src.Pix[o+3])
					}
				}
				r, g, b, a = r/n, g/n, b/n, a/n
			} else { // ampliação: bilinear
				fx, fy := (float64(x)+0.5)*xr-0.5, (float64(y)+0.5)*yr-0.5
				r, g, b, a = bilinearRGBA(src, fx, fy)
			}
			o := y*dst.Stride + x*4
			dst.Pix[o], dst.Pix[o+1], dst.Pix[o+2], dst.Pix[o+3] = clamp8(r), clamp8(g), clamp8(b), clamp8(a)
		}
	}
	return dst
}

func bilinearRGBA(src *image.RGBA, fx, fy float64) (r, g, b, a float64) {
	sw, sh := src.Bounds().Dx(), src.Bounds().Dy()
	x0, y0 := int(math.Floor(fx)), int(math.Floor(fy))
	tx, ty := fx-float64(x0), fy-float64(y0)
	px := func(x, y int) (float64, float64, float64, float64) {
		if x < 0 {
			x = 0
		} else if x >= sw {
			x = sw - 1
		}
		if y < 0 {
			y = 0
		} else if y >= sh {
			y = sh - 1
		}
		o := y*src.Stride + x*4
		return float64(src.Pix[o]), float64(src.Pix[o+1]), float64(src.Pix[o+2]), float64(src.Pix[o+3])
	}
	r00, g00, b00, a00 := px(x0, y0)
	r10, g10, b10, a10 := px(x0+1, y0)
	r01, g01, b01, a01 := px(x0, y0+1)
	r11, g11, b11, a11 := px(x0+1, y0+1)
	l := func(c00, c10, c01, c11 float64) float64 {
		return (c00*(1-tx)+c10*tx)*(1-ty) + (c01*(1-tx)+c11*tx)*ty
	}
	return l(r00, r10, r01, r11), l(g00, g10, g01, g11), l(b00, b10, b01, b11), l(a00, a10, a01, a11)
}

// ResizeGray redimensiona uma imagem em tons de cinza.
func ResizeGray(g *Gray, nw, nh int) *Gray {
	return GrayFromRGBA(ResizeRGBA(GrayToRGBA(g), nw, nh))
}

// CropRGBA recorta um retângulo (limitado à imagem).
func CropRGBA(src *image.RGBA, r image.Rectangle) *image.RGBA {
	r = r.Intersect(src.Bounds())
	out := image.NewRGBA(image.Rect(0, 0, r.Dx(), r.Dy()))
	for y := 0; y < r.Dy(); y++ {
		copy(out.Pix[y*out.Stride:y*out.Stride+r.Dx()*4], src.Pix[(r.Min.Y+y)*src.Stride+r.Min.X*4:])
	}
	return out
}

// AddBorder acrescenta uma margem com o valor v (o Tesseract reconhece melhor com margem).
func AddBorder(g *Gray, m int, v uint8) *Gray {
	out := NewGray(g.W+2*m, g.H+2*m)
	for i := range out.Pix {
		out.Pix[i] = v
	}
	for y := 0; y < g.H; y++ {
		copy(out.Pix[(y+m)*out.W+m:(y+m)*out.W+m+g.W], g.Pix[y*g.W:(y+1)*g.W])
	}
	return out
}

func clamp8(v float64) uint8 {
	if v < 0 {
		return 0
	}
	if v > 255 {
		return 255
	}
	return uint8(v + 0.5)
}

// DrawRect desenha o contorno de um retângulo com a espessura indicada.
func DrawRect(img *image.RGBA, r image.Rectangle, c color.RGBA, thick int) {
	r = r.Intersect(img.Bounds())
	for t := 0; t < thick; t++ {
		for x := r.Min.X; x < r.Max.X; x++ {
			setPx(img, x, r.Min.Y+t, c)
			setPx(img, x, r.Max.Y-1-t, c)
		}
		for y := r.Min.Y; y < r.Max.Y; y++ {
			setPx(img, r.Min.X+t, y, c)
			setPx(img, r.Max.X-1-t, y, c)
		}
	}
}

func setPx(img *image.RGBA, x, y int, c color.RGBA) {
	if image.Pt(x, y).In(img.Bounds()) {
		img.SetRGBA(x, y, c)
	}
}

// SavePNG grava a imagem em PNG.
func SavePNG(path string, img image.Image) error {
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()
	enc := png.Encoder{CompressionLevel: png.BestSpeed}
	return enc.Encode(f, img)
}
