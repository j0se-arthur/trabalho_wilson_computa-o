package pdi

import (
	"image"
	"math"
)

func dist(a, b Pt) float64 { return math.Hypot(a.X-b.X, a.Y-b.Y) }

// QuadInfo descreve a análise de confiabilidade de um quadrilátero.
type QuadInfo struct {
	Reliable bool
	Angle    float64 // inclinação da aresta superior, em graus
	OutW     int
	OutH     int
	Reason   string
}

// AnalyzeQuad decide se a correção de perspectiva é necessária e confiável.
// Só retorna Reliable=true quando o quadrilátero é coerente e há inclinação real.
func AnalyzeQuad(q [4]Pt, box image.Rectangle) QuadInfo {
	top, bot := dist(q[0], q[1]), dist(q[3], q[2])
	left, right := dist(q[0], q[3]), dist(q[1], q[2])
	info := QuadInfo{Angle: math.Atan2(q[1].Y-q[0].Y, q[1].X-q[0].X) * 180 / math.Pi}
	if top < 1 || bot < 1 || left < 1 || right < 1 {
		info.Reason = "arestas degeneradas"
		return info
	}
	area := 0.0
	for i := 0; i < 4; i++ {
		j := (i + 1) % 4
		area += q[i].X*q[j].Y - q[j].X*q[i].Y
	}
	area = math.Abs(area) / 2
	if area < 0.55*float64(box.Dx()*box.Dy()) {
		info.Reason = "quadrilátero pequeno demais em relação à região"
		return info
	}
	rt, rl := top/bot, left/right
	if rt < 0.75 || rt > 1.33 || rl < 0.75 || rl > 1.33 {
		info.Reason = "arestas opostas muito diferentes"
		return info
	}
	if math.Abs(info.Angle) > 25 {
		info.Reason = "inclinação acima do limite confiável"
		return info
	}
	needs := math.Abs(info.Angle) >= 1.5 || math.Abs(rt-1) > 0.08 || math.Abs(rl-1) > 0.08
	if !needs {
		info.Reason = "sem inclinação relevante (recorte simples)"
		return info
	}
	info.OutW, info.OutH = int(math.Round((top+bot)/2)), int(math.Round((left+right)/2))
	if info.OutH < 8 || float64(info.OutW)/float64(info.OutH) < 1.8 || float64(info.OutW)/float64(info.OutH) > 7 {
		info.Reason = "proporção resultante inválida"
		return info
	}
	info.Reliable = true
	return info
}

// WarpPerspective retifica o quadrilátero q (TL,TR,BR,BL) de src para um
// retângulo outW x outH, resolvendo a homografia e amostrando de forma bilinear.
func WarpPerspective(src *image.RGBA, q [4]Pt, outW, outH int) *image.RGBA {
	dst := [4]Pt{{0, 0}, {float64(outW), 0}, {float64(outW), float64(outH)}, {0, float64(outH)}}
	h, ok := homography(dst, q) // mapeia destino -> origem
	out := image.NewRGBA(image.Rect(0, 0, outW, outH))
	if !ok {
		return out
	}
	for y := 0; y < outH; y++ {
		for x := 0; x < outW; x++ {
			u, v := float64(x)+0.5, float64(y)+0.5
			d := h[6]*u + h[7]*v + 1
			sx := (h[0]*u+h[1]*v+h[2])/d - 0.5
			sy := (h[3]*u+h[4]*v+h[5])/d - 0.5
			r, g, b, a := bilinearRGBA(src, sx, sy)
			o := y*out.Stride + x*4
			out.Pix[o], out.Pix[o+1], out.Pix[o+2], out.Pix[o+3] = clamp8(r), clamp8(g), clamp8(b), clamp8(a)
		}
	}
	return out
}

// homography resolve o sistema 8x8 que leva os pontos a para os pontos b.
func homography(a, b [4]Pt) ([8]float64, bool) {
	var m [8][9]float64
	for i := 0; i < 4; i++ {
		x, y, u, v := a[i].X, a[i].Y, b[i].X, b[i].Y
		m[2*i] = [9]float64{x, y, 1, 0, 0, 0, -u * x, -u * y, u}
		m[2*i+1] = [9]float64{0, 0, 0, x, y, 1, -v * x, -v * y, v}
	}
	for c := 0; c < 8; c++ { // eliminação de Gauss com pivotamento parcial
		p := c
		for r := c + 1; r < 8; r++ {
			if math.Abs(m[r][c]) > math.Abs(m[p][c]) {
				p = r
			}
		}
		if math.Abs(m[p][c]) < 1e-9 {
			return [8]float64{}, false
		}
		m[c], m[p] = m[p], m[c]
		for r := 0; r < 8; r++ {
			if r == c {
				continue
			}
			f := m[r][c] / m[c][c]
			for k := c; k < 9; k++ {
				m[r][k] -= f * m[c][k]
			}
		}
	}
	var h [8]float64
	for i := 0; i < 8; i++ {
		h[i] = m[i][8] / m[i][i]
	}
	return h, true
}
