package pdi

import "math"

// Gaussian aplica um filtro gaussiano separável de tamanho ksize (ímpar).
func Gaussian(g *Gray, ksize int, sigma float64) *Gray {
	if ksize%2 == 0 {
		ksize++
	}
	if sigma <= 0 {
		sigma = 0.3*(float64(ksize-1)*0.5-1) + 0.8
	}
	r := ksize / 2
	k := make([]float64, ksize)
	var sum float64
	for i := range k {
		d := float64(i - r)
		k[i] = math.Exp(-d * d / (2 * sigma * sigma))
		sum += k[i]
	}
	for i := range k {
		k[i] /= sum
	}
	tmp := make([]float64, g.W*g.H)
	for y := 0; y < g.H; y++ {
		for x := 0; x < g.W; x++ {
			var s float64
			for i := -r; i <= r; i++ {
				s += k[i+r] * float64(g.At(x+i, y))
			}
			tmp[y*g.W+x] = s
		}
	}
	out := NewGray(g.W, g.H)
	for y := 0; y < g.H; y++ {
		for x := 0; x < g.W; x++ {
			var s float64
			for i := -r; i <= r; i++ {
				yy := y + i
				if yy < 0 {
					yy = 0
				} else if yy >= g.H {
					yy = g.H - 1
				}
				s += k[i+r] * tmp[yy*g.W+x]
			}
			out.Pix[y*g.W+x] = clamp8(s)
		}
	}
	return out
}

// Bilateral aplica o filtro bilateral: suaviza ruído preservando bordas.
func Bilateral(g *Gray, radius int, sigmaS, sigmaR float64) *Gray {
	var rng [256]float64
	for d := 0; d < 256; d++ {
		rng[d] = math.Exp(-float64(d*d) / (2 * sigmaR * sigmaR))
	}
	n := 2*radius + 1
	sp := make([]float64, n*n)
	for j := -radius; j <= radius; j++ {
		for i := -radius; i <= radius; i++ {
			sp[(j+radius)*n+i+radius] = math.Exp(-float64(i*i+j*j) / (2 * sigmaS * sigmaS))
		}
	}
	out := NewGray(g.W, g.H)
	for y := 0; y < g.H; y++ {
		for x := 0; x < g.W; x++ {
			c := int(g.Pix[y*g.W+x])
			var num, den float64
			for j := -radius; j <= radius; j++ {
				for i := -radius; i <= radius; i++ {
					v := int(g.At(x+i, y+j))
					d := v - c
					if d < 0 {
						d = -d
					}
					w := sp[(j+radius)*n+i+radius] * rng[d]
					num += w * float64(v)
					den += w
				}
			}
			out.Pix[y*g.W+x] = clamp8(num / den)
		}
	}
	return out
}

// EqualizeHist equaliza o histograma para aumentar o contraste global.
func EqualizeHist(g *Gray) *Gray {
	var hist [256]int
	for _, v := range g.Pix {
		hist[v]++
	}
	var cdf [256]int
	sum, cdfMin := 0, -1
	for i := 0; i < 256; i++ {
		sum += hist[i]
		cdf[i] = sum
		if cdfMin < 0 && hist[i] > 0 {
			cdfMin = sum
		}
	}
	total := len(g.Pix)
	out := NewGray(g.W, g.H)
	if total == cdfMin {
		copy(out.Pix, g.Pix)
		return out
	}
	var lut [256]uint8
	for i := 0; i < 256; i++ {
		lut[i] = clamp8(float64(cdf[i]-cdfMin) / float64(total-cdfMin) * 255)
	}
	for i, v := range g.Pix {
		out.Pix[i] = lut[v]
	}
	return out
}

// Sobel devolve a magnitude de |Gx| (bordas verticais, típicas dos caracteres
// de uma placa) e a magnitude total do gradiente.
func Sobel(g *Gray) (gx, mag *Gray) {
	gx, mag = NewGray(g.W, g.H), NewGray(g.W, g.H)
	for y := 0; y < g.H; y++ {
		for x := 0; x < g.W; x++ {
			a, b, c := int(g.At(x-1, y-1)), int(g.At(x, y-1)), int(g.At(x+1, y-1))
			d, f := int(g.At(x-1, y)), int(g.At(x+1, y))
			h, i, j := int(g.At(x-1, y+1)), int(g.At(x, y+1)), int(g.At(x+1, y+1))
			sx := (c + 2*f + j) - (a + 2*d + h)
			sy := (h + 2*i + j) - (a + 2*b + c)
			if sx < 0 {
				sx = -sx
			}
			gx.Pix[y*g.W+x] = clamp8(float64(sx) / 4)
			mag.Pix[y*g.W+x] = clamp8(math.Sqrt(float64(sx*sx+sy*sy)) / 4)
		}
	}
	return
}

// Otsu calcula o limiar que maximiza a variância entre classes.
func Otsu(g *Gray) int {
	var hist [256]float64
	for _, v := range g.Pix {
		hist[v]++
	}
	total := float64(len(g.Pix))
	var sumAll float64
	for i := 0; i < 256; i++ {
		sumAll += float64(i) * hist[i]
	}
	var wB, sumB, best float64
	thr := 0
	for t := 0; t < 256; t++ {
		wB += hist[t]
		if wB == 0 {
			continue
		}
		wF := total - wB
		if wF == 0 {
			break
		}
		sumB += float64(t) * hist[t]
		mB, mF := sumB/wB, (sumAll-sumB)/wF
		v := wB * wF * (mB - mF) * (mB - mF)
		if v > best {
			best, thr = v, t
		}
	}
	return thr
}

// Threshold binariza: pixel > t vira 255 (ou 0 se invert).
func Threshold(g *Gray, t int, invert bool) *Gray {
	out := NewGray(g.W, g.H)
	for i, v := range g.Pix {
		on := int(v) > t
		if on != invert {
			out.Pix[i] = 255
		}
	}
	return out
}

// AdaptiveThreshold binariza comparando cada pixel com a média local
// (calculada por imagem integral): saída 255 se v > média - c.
func AdaptiveThreshold(g *Gray, block int, c float64) *Gray {
	if block%2 == 0 {
		block++
	}
	w, h := g.W, g.H
	integ := make([]float64, (w+1)*(h+1))
	for y := 0; y < h; y++ {
		var row float64
		for x := 0; x < w; x++ {
			row += float64(g.Pix[y*w+x])
			integ[(y+1)*(w+1)+x+1] = integ[y*(w+1)+x+1] + row
		}
	}
	r := block / 2
	out := NewGray(w, h)
	for y := 0; y < h; y++ {
		y0, y1 := max(0, y-r), min(h, y+r+1)
		for x := 0; x < w; x++ {
			x0, x1 := max(0, x-r), min(w, x+r+1)
			s := integ[y1*(w+1)+x1] - integ[y0*(w+1)+x1] - integ[y1*(w+1)+x0] + integ[y0*(w+1)+x0]
			mean := s / float64((x1-x0)*(y1-y0))
			if float64(g.Pix[y*w+x]) > mean-c {
				out.Pix[y*w+x] = 255
			}
		}
	}
	return out
}

// Invert inverte as intensidades.
func Invert(g *Gray) *Gray {
	out := NewGray(g.W, g.H)
	for i, v := range g.Pix {
		out.Pix[i] = 255 - v
	}
	return out
}

// Mean devolve a intensidade média.
func Mean(g *Gray) float64 {
	var s float64
	for _, v := range g.Pix {
		s += float64(v)
	}
	return s / float64(len(g.Pix))
}
