package pdi

import (
	"image"
	"math"
	"sort"
)

// Candidate é uma região avaliada como possível placa (coordenadas da imagem de trabalho).
type Candidate struct {
	Box      image.Rectangle
	Corners  [4]Pt // TL, TR, BR, BL
	Aspect   float64
	Fill     float64
	Density  float64
	Contrast float64 // p90 - p10 da intensidade dentro da região
	Runs     float64 // média de segmentos de borda por linha (traços dos caracteres)
	Score    float64
	Accepted bool
	Reason   string // motivo da rejeição, quando houver
}

// Parâmetros dos critérios geométricos (proporção de placas egípcias ~ 2:1 a 4,5:1).
// A região detectada cobre a faixa de caracteres (mais larga que a placa inteira),
// por isso os limites de proporção são mais amplos; a placa é depois expandida.
const (
	minAspect    = 2.2
	maxAspect    = 10.0
	idealAspect  = 4.0
	minContrast  = 60.0
	minRuns      = 3.0
	minFill      = 0.45
	minScore     = 0.55
	maxPlates    = 5
	nmsThreshold = 0.30
)

// EvaluateComponents aplica os critérios (área, largura, altura, proporção,
// preenchimento retangular e densidade de bordas) a cada componente.
// edges é o mapa binário de bordas verticais antes da morfologia.
func EvaluateComponents(comps []Component, edges, ref *Gray) []Candidate {
	W, H := float64(edges.W), float64(edges.H)
	// imagem integral das bordas para contar pixels de borda em O(1)
	integ := make([]int, (edges.W+1)*(edges.H+1))
	for y := 0; y < edges.H; y++ {
		row := 0
		for x := 0; x < edges.W; x++ {
			if edges.Pix[y*edges.W+x] != 0 {
				row++
			}
			integ[(y+1)*(edges.W+1)+x+1] = integ[y*(edges.W+1)+x+1] + row
		}
	}
	var out []Candidate
	for _, c := range comps {
		w, h := float64(c.Box.Dx()), float64(c.Box.Dy())
		if w*h < 0.0008*W*H { // ruído muito pequeno: nem é listado
			continue
		}
		cd := Candidate{Box: c.Box, Corners: [4]Pt{c.TL, c.TR, c.BR, c.BL}}
		// Dimensões medidas no quadrilátero (não na caixa), para não penalizar
		// placas inclinadas.
		qw := (dist(c.TL, c.TR) + dist(c.BL, c.BR)) / 2
		qh := (dist(c.TL, c.BL) + dist(c.TR, c.BR)) / 2
		if qh < 1 {
			qh = 1
		}
		cd.Aspect = qw / qh
		cd.Fill = math.Min(float64(c.Area)/(qw*qh), 1)
		x0, y0, x1, y1 := c.Box.Min.X, c.Box.Min.Y, c.Box.Max.X, c.Box.Max.Y
		e := integ[y1*(edges.W+1)+x1] - integ[y0*(edges.W+1)+x1] - integ[y1*(edges.W+1)+x0] + integ[y0*(edges.W+1)+x0]
		cd.Density = math.Min(float64(e)/(qw*qh), 1)
		cd.Contrast = regionContrast(ref, c.Box)
		cd.Runs = rowRuns(edges, c.Box)
		switch {
		case w < 0.05*W || h < 0.015*H:
			cd.Reason = "muito pequena"
		case w > 0.85*W || w*h > 0.45*W*H:
			cd.Reason = "muito grande"
		case cd.Aspect < minAspect || cd.Aspect > maxAspect:
			cd.Reason = "proporção fora do padrão"
		case cd.Fill < minFill:
			cd.Reason = "pouco retangular"
		case cd.Contrast < minContrast:
			cd.Reason = "baixo contraste interno"
		case cd.Runs < minRuns:
			cd.Reason = "poucos traços verticais (não parece texto)"
		default:
			aspectScore := math.Exp(-math.Pow(math.Log(cd.Aspect/idealAspect), 2) / (2 * 0.4 * 0.4))
			densScore := math.Min(cd.Density/0.18, 1)
			contrastScore := math.Min(cd.Contrast/120, 1)
			runsScore := math.Min(cd.Runs/8, 1)
			cd.Score = 0.25*aspectScore + 0.15*cd.Fill + 0.2*densScore + 0.2*contrastScore + 0.2*runsScore
			if cd.Score < minScore {
				cd.Reason = "pontuação baixa"
			} else {
				cd.Accepted = true
			}
		}
		out = append(out, cd)
	}
	return out
}

// SelectPlates ordena os candidatos aceitos por pontuação e remove sobreposições (NMS).
func SelectPlates(cands []Candidate, bounds image.Rectangle) []Candidate {
	var acc []Candidate
	for _, c := range cands {
		if c.Accepted {
			acc = append(acc, ExpandToPlate(c, bounds))
		}
	}
	sort.Slice(acc, func(i, j int) bool { return acc[i].Score > acc[j].Score })
	var sel []Candidate
	for _, c := range acc {
		keep := true
		for _, s := range sel {
			if IoU(c.Box, s.Box) > nmsThreshold || containment(c.Box, s.Box) > 0.5 {
				keep = false
				break
			}
		}
		if keep {
			sel = append(sel, c)
			if len(sel) == maxPlates {
				break
			}
		}
	}
	return sel
}

// IoU calcula a interseção sobre a união de dois retângulos.
func IoU(a, b image.Rectangle) float64 {
	i := a.Intersect(b)
	if i.Empty() {
		return 0
	}
	ia := float64(i.Dx() * i.Dy())
	ua := float64(a.Dx()*a.Dy()+b.Dx()*b.Dy()) - ia
	return ia / ua
}

// regionContrast mede p90 - p10 das intensidades de ref dentro de box.
// Placas têm texto escuro sobre fundo claro, logo alto contraste interno.
func regionContrast(ref *Gray, box image.Rectangle) float64 {
	var hist [256]int
	n := 0
	for y := box.Min.Y; y < box.Max.Y; y++ {
		for x := box.Min.X; x < box.Max.X; x++ {
			hist[ref.At(x, y)]++
			n++
		}
	}
	if n == 0 {
		return 0
	}
	p := func(q float64) int {
		acc, target := 0, int(q*float64(n))
		for i := 0; i < 256; i++ {
			acc += hist[i]
			if acc >= target {
				return i
			}
		}
		return 255
	}
	return float64(p(0.9) - p(0.1))
}

// ExpandToPlate amplia verticalmente a região de caracteres para cobrir a placa
// inteira (proporção ~3,3:1), acompanhando a inclinação dos lados do quadrilátero.
func ExpandToPlate(c Candidate, bounds image.Rectangle) Candidate {
	q := c.Corners
	w, h := dist(q[0], q[1]), dist(q[0], q[3])
	if h < 1 {
		return c
	}
	k := (w / 3.6) / h
	if k > 1 {
		// 60% do acréscimo para cima (faixa superior das placas), 40% para baixo
		eu, ed := (k-1)*0.6, (k-1)*0.4
		dl := Pt{q[3].X - q[0].X, q[3].Y - q[0].Y}
		dr := Pt{q[2].X - q[1].X, q[2].Y - q[1].Y}
		q[0], q[1] = Pt{q[0].X - dl.X*eu, q[0].Y - dl.Y*eu}, Pt{q[1].X - dr.X*eu, q[1].Y - dr.Y*eu}
		q[3], q[2] = Pt{q[3].X + dl.X*ed, q[3].Y + dl.Y*ed}, Pt{q[2].X + dr.X*ed, q[2].Y + dr.Y*ed}
	}
	minX, minY, maxX, maxY := math.Inf(1), math.Inf(1), math.Inf(-1), math.Inf(-1)
	for _, p := range q {
		minX, maxX = math.Min(minX, p.X), math.Max(maxX, p.X)
		minY, maxY = math.Min(minY, p.Y), math.Max(maxY, p.Y)
	}
	c.Corners = q
	c.Box = image.Rect(int(minX), int(minY), int(math.Ceil(maxX)), int(math.Ceil(maxY))).Intersect(bounds)
	return c
}

// rowRuns calcula a média de segmentos contíguos de borda por linha na faixa
// central da região: texto tem muitos traços verticais por linha.
func rowRuns(edges *Gray, box image.Rectangle) float64 {
	y0 := box.Min.Y + box.Dy()/5
	y1 := box.Max.Y - box.Dy()/5
	if y1 <= y0 {
		y0, y1 = box.Min.Y, box.Max.Y
	}
	total, rows := 0, 0
	for y := y0; y < y1; y++ {
		prev := false
		for x := box.Min.X; x < box.Max.X; x++ {
			on := edges.At(x, y) != 0
			if on && !prev {
				total++
			}
			prev = on
		}
		rows++
	}
	if rows == 0 {
		return 0
	}
	return float64(total) / float64(rows)
}

// containment: fração da menor região que está dentro da interseção.
func containment(a, b image.Rectangle) float64 {
	i := a.Intersect(b)
	if i.Empty() {
		return 0
	}
	m := math.Min(float64(a.Dx()*a.Dy()), float64(b.Dx()*b.Dy()))
	return float64(i.Dx()*i.Dy()) / m
}
