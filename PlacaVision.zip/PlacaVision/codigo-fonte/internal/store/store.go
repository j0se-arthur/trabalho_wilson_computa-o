// Pacote store cuida da persistência em SQLite: criação automática do banco,
// inserção, consulta, listagem, exclusão e estatísticas do dashboard.
package store

import (
	"database/sql"
	"fmt"
	"strings"
	"time"

	_ "github.com/mattn/go-sqlite3"

	"placas/internal/metrics"
)

type Store struct{ db *sql.DB }

const schema = `
CREATE TABLE IF NOT EXISTS analyses (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	original_filename TEXT NOT NULL,
	processed_at TEXT NOT NULL,
	processing_time REAL NOT NULL DEFAULT 0,
	status TEXT NOT NULL DEFAULT 'processando',
	total_plates INTEGER NOT NULL DEFAULT 0,
	width INTEGER NOT NULL DEFAULT 0,
	height INTEGER NOT NULL DEFAULT 0,
	original_path TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS plates (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	analysis_id INTEGER NOT NULL REFERENCES analyses(id) ON DELETE CASCADE,
	recognized_text TEXT NOT NULL DEFAULT '',
	confidence REAL NOT NULL DEFAULT 0,
	detection_status TEXT NOT NULL DEFAULT 'detectada',
	x INTEGER NOT NULL, y INTEGER NOT NULL, width INTEGER NOT NULL, height INTEGER NOT NULL,
	image_path TEXT NOT NULL DEFAULT '',
	score REAL NOT NULL DEFAULT 0,
	method TEXT NOT NULL DEFAULT '',
	ocr_status TEXT NOT NULL DEFAULT 'pendente',
	ocr_lang TEXT NOT NULL DEFAULT '',
	ground_truth TEXT,
	cer REAL
);
CREATE TABLE IF NOT EXISTS processing_steps (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	analysis_id INTEGER NOT NULL REFERENCES analyses(id) ON DELETE CASCADE,
	step_name TEXT NOT NULL,
	image_path TEXT NOT NULL DEFAULT '',
	execution_time REAL NOT NULL DEFAULT 0,
	status TEXT NOT NULL,
	title TEXT NOT NULL DEFAULT '',
	detail TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_plates_analysis ON plates(analysis_id);
CREATE INDEX IF NOT EXISTS idx_steps_analysis ON processing_steps(analysis_id);
CREATE INDEX IF NOT EXISTS idx_analyses_date ON analyses(processed_at);
CREATE INDEX IF NOT EXISTS idx_analyses_status ON analyses(status);
CREATE INDEX IF NOT EXISTS idx_plates_ocr ON plates(ocr_status);
`

// Open abre (criando, se necessário) o banco e aplica as migrações.
func Open(path string) (*Store, error) {
	db, err := sql.Open("sqlite3", "file:"+path+"?_foreign_keys=on&_busy_timeout=5000&_journal_mode=WAL")
	if err != nil {
		return nil, err
	}
	db.SetMaxOpenConns(1) // SQLite: uma conexão evita "database is locked"
	if _, err := db.Exec(schema); err != nil {
		db.Close()
		return nil, fmt.Errorf("migração: %w", err)
	}
	return &Store{db: db}, nil
}

func (s *Store) Close() error { return s.db.Close() }

// ---- modelos ----

type Step struct {
	Name   string  `json:"name"`
	Title  string  `json:"title"`
	File   string  `json:"file"`
	Millis float64 `json:"millis"`
	Status string  `json:"status"`
	Detail string  `json:"detail"`
}

type Plate struct {
	ID          int64    `json:"id"`
	AnalysisID  int64    `json:"analysisId"`
	Text        string   `json:"text"`
	Confidence  float64  `json:"confidence"`
	Detection   string   `json:"detectionStatus"`
	X           int      `json:"x"`
	Y           int      `json:"y"`
	W           int      `json:"w"`
	H           int      `json:"h"`
	File        string   `json:"file"`
	Score       float64  `json:"score"`
	Method      string   `json:"method"`
	OCRStatus   string   `json:"ocrStatus"`
	OCRLang     string   `json:"ocrLang"`
	GroundTruth *string  `json:"groundTruth"`
	CER         *float64 `json:"cer"`
	OCRFiles    []string `json:"ocrFiles,omitempty"`
}

type Analysis struct {
	ID          int64   `json:"id"`
	Filename    string  `json:"filename"`
	ProcessedAt string  `json:"processedAt"`
	Millis      float64 `json:"processingTime"`
	Status      string  `json:"status"`
	TotalPlate  int     `json:"totalPlates"`
	Width       int     `json:"width"`
	Height      int     `json:"height"`
	Original    string  `json:"original"`
	Plates      []Plate `json:"plates,omitempty"`
	Steps       []Step  `json:"steps,omitempty"`
	Texts       string  `json:"texts,omitempty"` // textos reconhecidos (listagem)
}

// ---- escrita ----

func (s *Store) CreateAnalysis(filename string) (int64, error) {
	r, err := s.db.Exec(`INSERT INTO analyses(original_filename, processed_at) VALUES(?,?)`,
		filename, time.Now().Format(time.RFC3339))
	if err != nil {
		return 0, err
	}
	return r.LastInsertId()
}

// FinishAnalysis grava o resultado do processamento (etapas e placas) numa transação.
func (s *Store) FinishAnalysis(id int64, status string, millis float64, w, h int, original string, steps []Step, plates []Plate) ([]Plate, error) {
	tx, err := s.db.Begin()
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()
	if _, err := tx.Exec(`UPDATE analyses SET status=?, processing_time=?, total_plates=?, width=?, height=?, original_path=? WHERE id=?`,
		status, millis, len(plates), w, h, original, id); err != nil {
		return nil, err
	}
	for _, st := range steps {
		if _, err := tx.Exec(`INSERT INTO processing_steps(analysis_id, step_name, image_path, execution_time, status, title, detail) VALUES(?,?,?,?,?,?,?)`,
			id, st.Name, st.File, st.Millis, st.Status, st.Title, st.Detail); err != nil {
			return nil, err
		}
	}
	for i := range plates {
		p := &plates[i]
		r, err := tx.Exec(`INSERT INTO plates(analysis_id, detection_status, x, y, width, height, image_path, score, method) VALUES(?,?,?,?,?,?,?,?,?)`,
			id, "detectada", p.X, p.Y, p.W, p.H, p.File, p.Score, p.Method)
		if err != nil {
			return nil, err
		}
		p.ID, _ = r.LastInsertId()
		p.AnalysisID = id
		p.OCRStatus = "pendente"
		p.Detection = "detectada"
	}
	return plates, tx.Commit()
}

// FailAnalysis marca a análise como erro.
func (s *Store) FailAnalysis(id int64, millis float64) error {
	_, err := s.db.Exec(`UPDATE analyses SET status='erro', processing_time=? WHERE id=?`, millis, id)
	return err
}

// SaveOCR grava o resultado do OCR de uma placa. Texto vazio = "sem_resultado".
// O texto é gravado exatamente como reconhecido (apenas espaços nas pontas são removidos).
func (s *Store) SaveOCR(plateID int64, text string, conf float64, lang string) error {
	text = strings.TrimSpace(text)
	status := "reconhecido"
	if text == "" {
		status = "sem_resultado"
	}
	res, err := s.db.Exec(`UPDATE plates SET recognized_text=?, confidence=?, ocr_status=?, ocr_lang=?,
		cer = CASE WHEN ground_truth IS NULL THEN NULL ELSE cer END WHERE id=?`, text, conf, status, lang, plateID)
	if err != nil {
		return err
	}
	if n, _ := res.RowsAffected(); n == 0 {
		return sql.ErrNoRows
	}
	// recalcula o CER caso já exista gabarito
	var gt sql.NullString
	if err := s.db.QueryRow(`SELECT ground_truth FROM plates WHERE id=?`, plateID).Scan(&gt); err == nil && gt.Valid {
		_, err = s.db.Exec(`UPDATE plates SET cer=? WHERE id=?`, metrics.CER(metrics.StripBidi(gt.String), metrics.StripBidi(text)), plateID)
		return err
	}
	return nil
}

// SaveGroundTruth grava o texto correto informado pelo usuário e calcula o CER.
func (s *Store) SaveGroundTruth(plateID int64, truth string) error {
	truth = strings.TrimSpace(truth)
	var rec string
	if err := s.db.QueryRow(`SELECT recognized_text FROM plates WHERE id=?`, plateID).Scan(&rec); err != nil {
		return err
	}
	if truth == "" {
		_, err := s.db.Exec(`UPDATE plates SET ground_truth=NULL, cer=NULL WHERE id=?`, plateID)
		return err
	}
	_, err := s.db.Exec(`UPDATE plates SET ground_truth=?, cer=? WHERE id=?`, truth, metrics.CER(metrics.StripBidi(truth), metrics.StripBidi(rec)), plateID)
	return err
}

// DeleteAnalysis remove a análise (placas e etapas saem por ON DELETE CASCADE).
func (s *Store) DeleteAnalysis(id int64) error {
	res, err := s.db.Exec(`DELETE FROM analyses WHERE id=?`, id)
	if err != nil {
		return err
	}
	if n, _ := res.RowsAffected(); n == 0 {
		return sql.ErrNoRows
	}
	return nil
}

// ---- leitura ----

func (s *Store) GetAnalysis(id int64) (*Analysis, error) {
	a := &Analysis{}
	err := s.db.QueryRow(`SELECT id, original_filename, processed_at, processing_time, status, total_plates, width, height, original_path FROM analyses WHERE id=?`, id).
		Scan(&a.ID, &a.Filename, &a.ProcessedAt, &a.Millis, &a.Status, &a.TotalPlate, &a.Width, &a.Height, &a.Original)
	if err != nil {
		return nil, err
	}
	rows, err := s.db.Query(`SELECT id, recognized_text, confidence, detection_status, x, y, width, height, image_path, score, method, ocr_status, ocr_lang, ground_truth, cer FROM plates WHERE analysis_id=? ORDER BY id`, id)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		p := Plate{AnalysisID: id}
		var gt sql.NullString
		var cer sql.NullFloat64
		if err := rows.Scan(&p.ID, &p.Text, &p.Confidence, &p.Detection, &p.X, &p.Y, &p.W, &p.H, &p.File, &p.Score, &p.Method, &p.OCRStatus, &p.OCRLang, &gt, &cer); err != nil {
			return nil, err
		}
		if gt.Valid {
			v := gt.String
			p.GroundTruth = &v
		}
		if cer.Valid {
			v := cer.Float64
			p.CER = &v
		}
		a.Plates = append(a.Plates, p)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	srows, err := s.db.Query(`SELECT step_name, title, image_path, execution_time, status, detail FROM processing_steps WHERE analysis_id=? ORDER BY id`, id)
	if err != nil {
		return nil, err
	}
	defer srows.Close()
	for srows.Next() {
		var st Step
		if err := srows.Scan(&st.Name, &st.Title, &st.File, &st.Millis, &st.Status, &st.Detail); err != nil {
			return nil, err
		}
		a.Steps = append(a.Steps, st)
	}
	return a, srows.Err()
}

// List devolve o histórico com filtros: q (nome do arquivo ou texto reconhecido) e status.
func (s *Store) List(q, status string, limit, offset int) ([]Analysis, int, error) {
	where, args := []string{"1=1"}, []any{}
	if q = strings.TrimSpace(q); q != "" {
		like := "%" + strings.NewReplacer(`\`, `\\`, `%`, `\%`, `_`, `\_`).Replace(q) + "%"
		where = append(where, `(a.original_filename LIKE ? ESCAPE '\' OR EXISTS (SELECT 1 FROM plates p WHERE p.analysis_id=a.id AND p.recognized_text LIKE ? ESCAPE '\'))`)
		args = append(args, like, like)
	}
	if status != "" {
		where = append(where, `a.status = ?`)
		args = append(args, status)
	}
	cond := strings.Join(where, " AND ")
	var total int
	if err := s.db.QueryRow(`SELECT COUNT(*) FROM analyses a WHERE `+cond, args...).Scan(&total); err != nil {
		return nil, 0, err
	}
	rows, err := s.db.Query(`SELECT a.id, a.original_filename, a.processed_at, a.processing_time, a.status, a.total_plates,
		COALESCE((SELECT group_concat(recognized_text, ' | ') FROM plates p WHERE p.analysis_id=a.id AND p.recognized_text <> ''), '')
		FROM analyses a WHERE `+cond+` ORDER BY a.id DESC LIMIT ? OFFSET ?`, append(args, limit, offset)...)
	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()
	var out []Analysis
	for rows.Next() {
		var a Analysis
		if err := rows.Scan(&a.ID, &a.Filename, &a.ProcessedAt, &a.Millis, &a.Status, &a.TotalPlate, &a.Texts); err != nil {
			return nil, 0, err
		}
		out = append(out, a)
	}
	return out, total, rows.Err()
}

// Stats reúne os indicadores do dashboard, todos calculados a partir dos dados reais.
type Stats struct {
	Images        int      `json:"images"`
	WithPlates    int      `json:"imagesWithPlates"`
	Plates        int      `json:"plates"`
	Recognized    int      `json:"recognized"`
	NoResult      int      `json:"noResult"`
	Pending       int      `json:"pending"`
	SuccessRate   float64  `json:"successRate"` // reconhecidas / (reconhecidas + sem resultado)
	AvgMillis     float64  `json:"avgMillis"`
	AvgConfidence float64  `json:"avgConfidence"`
	Evaluated     int      `json:"evaluated"` // placas com gabarito
	AvgCER        *float64 `json:"avgCER"`
	ExactMatch    *float64 `json:"exactMatchRate"`
	PerDay        []Day    `json:"perDay"`
}

type Day struct {
	Day    string `json:"day"`
	Images int    `json:"images"`
	Plates int    `json:"plates"`
}

func (s *Store) Stats() (*Stats, error) {
	st := &Stats{}
	err := s.db.QueryRow(`SELECT COUNT(*), COALESCE(SUM(total_plates>0),0), COALESCE(SUM(total_plates),0), COALESCE(AVG(NULLIF(processing_time,0)),0) FROM analyses WHERE status <> 'erro' AND status <> 'processando'`).
		Scan(&st.Images, &st.WithPlates, &st.Plates, &st.AvgMillis)
	if err != nil {
		return nil, err
	}
	err = s.db.QueryRow(`SELECT COALESCE(SUM(ocr_status='reconhecido'),0), COALESCE(SUM(ocr_status='sem_resultado'),0), COALESCE(SUM(ocr_status='pendente'),0),
		COALESCE(AVG(CASE WHEN ocr_status='reconhecido' THEN confidence END),0) FROM plates`).Scan(&st.Recognized, &st.NoResult, &st.Pending, &st.AvgConfidence)
	if err != nil {
		return nil, err
	}
	if d := st.Recognized + st.NoResult; d > 0 {
		st.SuccessRate = float64(st.Recognized) / float64(d)
	}
	var avgCER sql.NullFloat64
	var exact sql.NullFloat64
	err = s.db.QueryRow(`SELECT COUNT(*), AVG(cer), AVG(cer = 0) FROM plates WHERE ground_truth IS NOT NULL AND ocr_status <> 'pendente'`).Scan(&st.Evaluated, &avgCER, &exact)
	if err != nil {
		return nil, err
	}
	if avgCER.Valid {
		st.AvgCER = &avgCER.Float64
	}
	if exact.Valid {
		st.ExactMatch = &exact.Float64
	}
	rows, err := s.db.Query(`SELECT substr(processed_at,1,10), COUNT(*), COALESCE(SUM(total_plates),0) FROM analyses WHERE status <> 'erro' AND status <> 'processando' GROUP BY 1 ORDER BY 1 DESC LIMIT 14`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var d Day
		if err := rows.Scan(&d.Day, &d.Images, &d.Plates); err != nil {
			return nil, err
		}
		st.PerDay = append([]Day{d}, st.PerDay...)
	}
	return st, rows.Err()
}
