package store

import (
	"database/sql"
	"errors"
	"math"
	"path/filepath"
	"testing"
)

func open(t *testing.T) *Store {
	t.Helper()
	s, err := Open(filepath.Join(t.TempDir(), "t.db")) // o banco é criado automaticamente
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { s.Close() })
	return s
}

func seed(t *testing.T, s *Store, name string, nPlates int) (int64, []Plate) {
	t.Helper()
	id, err := s.CreateAnalysis(name)
	if err != nil {
		t.Fatal(err)
	}
	var pl []Plate
	for i := 0; i < nPlates; i++ {
		pl = append(pl, Plate{X: 1, Y: 2, W: 30, H: 10, File: "p.png", Score: .8, Method: "recorte"})
	}
	out, err := s.FinishAnalysis(id, map[bool]string{true: "concluido", false: "sem_placas"}[nPlates > 0], 123.4, 640, 480, "original.jpg",
		[]Step{{Name: "cinza", Title: "Cinza", File: "02_cinza.png", Millis: 1.5, Status: "ok"}}, pl)
	if err != nil {
		t.Fatal(err)
	}
	return id, out
}

func TestInsertGetAndCascadeDelete(t *testing.T) {
	s := open(t)
	id, plates := seed(t, s, "a.jpg", 2)
	a, err := s.GetAnalysis(id)
	if err != nil || len(a.Plates) != 2 || len(a.Steps) != 1 || a.TotalPlate != 2 || plates[0].ID == 0 {
		t.Fatalf("leitura inesperada: %+v err=%v", a, err)
	}
	if err := s.DeleteAnalysis(id); err != nil {
		t.Fatal(err)
	}
	if _, err := s.GetAnalysis(id); !errors.Is(err, sql.ErrNoRows) {
		t.Fatalf("a análise deveria ter sido excluída: %v", err)
	}
	var n int
	s.db.QueryRow(`SELECT COUNT(*) FROM plates`).Scan(&n)
	if n != 0 {
		t.Fatalf("as placas deveriam sair em cascata, restaram %d", n)
	}
	if err := s.DeleteAnalysis(id); !errors.Is(err, sql.ErrNoRows) {
		t.Fatalf("excluir inexistente deveria falhar")
	}
}

func TestOCRStatusAndCER(t *testing.T) {
	s := open(t)
	_, pl := seed(t, s, "a.jpg", 2)
	if err := s.SaveOCR(pl[0].ID, "  1234 ABC \n", 91.5, "eng"); err != nil {
		t.Fatal(err)
	}
	if err := s.SaveOCR(pl[1].ID, "", 0, "eng"); err != nil {
		t.Fatal(err)
	}
	if err := s.SaveGroundTruth(pl[0].ID, "1284 ABC"); err != nil {
		t.Fatal(err)
	}
	a, _ := s.GetAnalysis(pl[0].AnalysisID)
	if a.Plates[0].Text != "1234 ABC" || a.Plates[0].OCRStatus != "reconhecido" || a.Plates[1].OCRStatus != "sem_resultado" {
		t.Fatalf("OCR gravado incorretamente: %+v", a.Plates)
	}
	if a.Plates[0].CER == nil || math.Abs(*a.Plates[0].CER-1.0/8) > 1e-9 {
		t.Fatalf("CER esperado 0,125, obtido %v", a.Plates[0].CER)
	}
	// refazer o OCR recalcula o CER
	s.SaveOCR(pl[0].ID, "1284 ABC", 80, "eng")
	a, _ = s.GetAnalysis(pl[0].AnalysisID)
	if *a.Plates[0].CER != 0 {
		t.Fatalf("CER deveria zerar após leitura exata")
	}
	if err := s.SaveOCR(9999, "x", 1, "eng"); !errors.Is(err, sql.ErrNoRows) {
		t.Fatalf("placa inexistente deveria retornar ErrNoRows")
	}
}

func TestListFiltersAndSearch(t *testing.T) {
	s := open(t)
	_, p1 := seed(t, s, "carro_azul.jpg", 1)
	seed(t, s, "rua.png", 0)
	s.SaveOCR(p1[0].ID, "٣٤٥٦ أ ب", 70, "ara")
	items, total, err := s.List("azul", "", 10, 0)
	if err != nil || total != 1 || items[0].Filename != "carro_azul.jpg" {
		t.Fatalf("busca por nome falhou: %+v %v", items, err)
	}
	if _, total, _ := s.List("٣٤٥٦", "", 10, 0); total != 1 {
		t.Fatalf("busca por texto reconhecido falhou")
	}
	if _, total, _ := s.List("", "sem_placas", 10, 0); total != 1 {
		t.Fatalf("filtro de status falhou")
	}
	if _, total, _ := s.List("100%", "", 10, 0); total != 0 {
		t.Fatalf("%% deve ser tratado literalmente")
	}
}

func TestStatsUseRealData(t *testing.T) {
	s := open(t)
	st, _ := s.Stats()
	if st.Images != 0 || st.Plates != 0 || st.AvgCER != nil {
		t.Fatalf("banco vazio deve gerar zeros: %+v", st)
	}
	_, p := seed(t, s, "a.jpg", 3)
	seed(t, s, "b.jpg", 0)
	s.SaveOCR(p[0].ID, "1234", 90, "eng")
	s.SaveOCR(p[1].ID, "", 0, "eng")
	s.SaveGroundTruth(p[0].ID, "1234")
	st, err := s.Stats()
	if err != nil {
		t.Fatal(err)
	}
	if st.Images != 2 || st.WithPlates != 1 || st.Plates != 3 || st.Recognized != 1 || st.NoResult != 1 || st.Pending != 1 {
		t.Fatalf("contagens incorretas: %+v", st)
	}
	if st.SuccessRate != 0.5 || st.AvgCER == nil || *st.AvgCER != 0 || *st.ExactMatch != 1 || st.Evaluated != 1 {
		t.Fatalf("taxas incorretas: %+v", st)
	}
}

func TestBidiMarksIgnoredInCER(t *testing.T) {
	s := open(t)
	_, p := seed(t, s, "a.jpg", 1)
	s.SaveOCR(p[0].ID, "EGYPT \u200f\u0645\u0635\u0631\u200e", 90, "ara+eng")
	s.SaveGroundTruth(p[0].ID, "EGYPT \u0645\u0635\u0631")
	a, _ := s.GetAnalysis(p[0].AnalysisID)
	if *a.Plates[0].CER != 0 {
		t.Fatalf("marcas de direção não devem contar como erro: %v", *a.Plates[0].CER)
	}
	if a.Plates[0].Text != "EGYPT \u200f\u0645\u0635\u0631\u200e" {
		t.Fatalf("o texto reconhecido não deve ser alterado")
	}
}
