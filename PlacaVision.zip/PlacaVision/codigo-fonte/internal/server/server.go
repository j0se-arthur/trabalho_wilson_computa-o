// Pacote server expõe a aplicação web: páginas, API JSON e arquivos de resultado.
package server

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"html/template"
	"image"
	"image/jpeg"
	"image/png"
	"io"
	"io/fs"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"

	"database/sql"

	"placas/internal/bmp"
	"placas/internal/pdi"
	"placas/internal/store"
	"placas/web"
)

const (
	maxUpload     = 15 << 20 // 15 MB
	maxPixels     = 25_000_000
	minSide       = 64
	maxConcurrent = 2
	processLimit  = 90 * time.Second
	queueWait     = 30 * time.Second
)

var (
	safeFile = regexp.MustCompile(`^[A-Za-z0-9_.-]{1,80}$`)
	langRe   = regexp.MustCompile(`^[a-z]{3}(\+[a-z]{3}){0,3}$`)
	badName  = regexp.MustCompile(`[^A-Za-z0-9._ -]+`)
)

type Server struct {
	st      *store.Store
	results string
	log     *log.Logger
	sem     chan struct{}
	tmpl    map[string]*template.Template
	mu      sync.Mutex
}

func New(st *store.Store, dataDir string, lg *log.Logger) (*Server, error) {
	s := &Server{st: st, results: filepath.Join(dataDir, "results"), log: lg, sem: make(chan struct{}, maxConcurrent), tmpl: map[string]*template.Template{}}
	if err := os.MkdirAll(s.results, 0o755); err != nil {
		return nil, err
	}
	for _, p := range []string{"index", "processar", "historico", "analise", "dashboard", "sobre"} {
		t, err := template.ParseFS(web.FS, "templates/layout.html", "templates/"+p+".html")
		if err != nil {
			return nil, err
		}
		s.tmpl[p] = t
	}
	return s, nil
}

// Handler monta as rotas (roteador padrão do Go 1.22) e os middlewares.
func (s *Server) Handler() http.Handler {
	mux := http.NewServeMux()
	page := func(name string) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			var buf bytes.Buffer
			if err := s.tmpl[name].ExecuteTemplate(&buf, "layout", map[string]string{"Page": name, "ID": r.PathValue("id")}); err != nil {
				s.fail(w, http.StatusInternalServerError, "erro ao montar a página", err)
				return
			}
			w.Header().Set("Content-Type", "text/html; charset=utf-8")
			w.Write(buf.Bytes())
		}
	}
	mux.HandleFunc("GET /{$}", page("index"))
	mux.HandleFunc("GET /processar", page("processar"))
	mux.HandleFunc("GET /historico", page("historico"))
	mux.HandleFunc("GET /analise/{id}", page("analise"))
	mux.HandleFunc("GET /dashboard", page("dashboard"))
	mux.HandleFunc("GET /sobre", page("sobre"))

	static, _ := fs.Sub(web.FS, "static")
	mux.Handle("GET /static/", http.StripPrefix("/static/", cacheControl(http.FileServerFS(static))))
	mux.HandleFunc("GET /results/{id}/{file}", s.serveResult)

	mux.HandleFunc("POST /api/analyze", s.analyze)
	mux.HandleFunc("GET /api/analyses", s.list)
	mux.HandleFunc("GET /api/analyses/{id}", s.get)
	mux.HandleFunc("DELETE /api/analyses/{id}", s.remove)
	mux.HandleFunc("POST /api/plates/{id}/ocr", s.saveOCR)
	mux.HandleFunc("POST /api/plates/{id}/truth", s.saveTruth)
	mux.HandleFunc("GET /api/stats", s.stats)
	return s.recoverer(s.security(mux))
}

func cacheControl(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "public, max-age=3600")
		h.ServeHTTP(w, r)
	})
}

// security aplica cabeçalhos de proteção e registra as requisições.
func (s *Server) security(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		h := w.Header()
		h.Set("X-Content-Type-Options", "nosniff")
		h.Set("X-Frame-Options", "DENY")
		h.Set("Referrer-Policy", "no-referrer")
		h.Set("Content-Security-Policy", "default-src 'self'; script-src 'self' 'wasm-unsafe-eval' blob:; worker-src 'self' blob:; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self' data: blob:; object-src 'none'; base-uri 'none'")
		t0 := time.Now()
		next.ServeHTTP(w, r)
		if !strings.HasPrefix(r.URL.Path, "/static/") && !strings.HasPrefix(r.URL.Path, "/results/") {
			s.log.Printf("%s %s (%v)", r.Method, r.URL.Path, time.Since(t0).Round(time.Millisecond))
		}
	})
}

// recoverer impede que um pânico derrube o servidor.
func (s *Server) recoverer(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() {
			if rec := recover(); rec != nil {
				s.log.Printf("PÂNICO em %s %s: %v", r.Method, r.URL.Path, rec)
				writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "erro interno do servidor"})
			}
		}()
		next.ServeHTTP(w, r)
	})
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(v)
}

func (s *Server) fail(w http.ResponseWriter, code int, msg string, err error) {
	if err != nil {
		s.log.Printf("ERRO: %s: %v", msg, err)
	}
	writeJSON(w, code, map[string]string{"error": msg})
}

func idParam(r *http.Request) (int64, bool) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	return id, err == nil && id > 0
}

// ---------- upload e processamento ----------

func sanitizeName(n string) string {
	n = filepath.Base(strings.ReplaceAll(n, `\`, "/"))
	n = strings.TrimSpace(badName.ReplaceAllString(n, "_"))
	if len(n) > 80 {
		n = n[len(n)-80:]
	}
	if n == "" || n == "." {
		n = "imagem"
	}
	return n
}

func (s *Server) analyze(w http.ResponseWriter, r *http.Request) {
	r.Body = http.MaxBytesReader(w, r.Body, maxUpload+(1<<20))
	if err := r.ParseMultipartForm(maxUpload); err != nil {
		var mbe *http.MaxBytesError
		if errors.As(err, &mbe) {
			s.fail(w, http.StatusRequestEntityTooLarge, "arquivo maior que 15 MB", nil)
			return
		}
		s.fail(w, http.StatusBadRequest, "envio inválido (use multipart/form-data com o campo 'image')", err)
		return
	}
	file, hdr, err := r.FormFile("image")
	if err != nil {
		s.fail(w, http.StatusBadRequest, "nenhuma imagem enviada (campo 'image')", err)
		return
	}
	defer file.Close()
	ext := strings.ToLower(filepath.Ext(hdr.Filename))
	if ext != ".jpg" && ext != ".jpeg" && ext != ".png" && ext != ".bmp" {
		s.fail(w, http.StatusUnsupportedMediaType, "formato não permitido: use JPG, JPEG, PNG ou BMP", nil)
		return
	}
	data, err := io.ReadAll(io.LimitReader(file, maxUpload+1))
	if err != nil || len(data) > maxUpload {
		s.fail(w, http.StatusRequestEntityTooLarge, "arquivo maior que 15 MB", err)
		return
	}
	// valida o conteúdo real (não confia na extensão nem no Content-Type enviados)
	cfg, format, err := image.DecodeConfig(bytes.NewReader(data))
	if err != nil || (format != "jpeg" && format != "png" && format != "bmp") {
		s.fail(w, http.StatusUnsupportedMediaType, "o arquivo não é uma imagem JPG, PNG ou BMP válida", err)
		return
	}
	if cfg.Width < minSide || cfg.Height < minSide {
		s.fail(w, http.StatusUnprocessableEntity, fmt.Sprintf("imagem pequena demais (mínimo %dx%d px)", minSide, minSide), nil)
		return
	}
	if cfg.Width*cfg.Height > maxPixels {
		s.fail(w, http.StatusUnprocessableEntity, "imagem com resolução acima de 25 megapixels", nil)
		return
	}
	img, _, err := image.Decode(bytes.NewReader(data))
	if err != nil {
		s.fail(w, http.StatusUnprocessableEntity, "não foi possível decodificar a imagem", err)
		return
	}
	data = nil

	// controle de concorrência: no máximo maxConcurrent processamentos simultâneos
	select {
	case s.sem <- struct{}{}:
		defer func() { <-s.sem }()
	case <-time.After(queueWait):
		s.fail(w, http.StatusServiceUnavailable, "servidor ocupado; tente novamente em instantes", nil)
		return
	case <-r.Context().Done():
		return
	}

	name := sanitizeName(hdr.Filename)
	id, err := s.st.CreateAnalysis(name)
	if err != nil {
		s.fail(w, http.StatusInternalServerError, "erro ao registrar a análise", err)
		return
	}
	dir := filepath.Join(s.results, strconv.FormatInt(id, 10))
	t0 := time.Now()

	type out struct {
		res *pdi.Result
		err error
	}
	done := make(chan out, 1)
	go func() {
		defer func() {
			if rec := recover(); rec != nil {
				done <- out{nil, fmt.Errorf("pânico no pipeline: %v", rec)}
			}
		}()
		res, err := pdi.Process(img, dir)
		done <- out{res, err}
	}()
	ctx, cancel := context.WithTimeout(r.Context(), processLimit)
	defer cancel()
	var o out
	select {
	case o = <-done:
	case <-ctx.Done():
		s.st.FailAnalysis(id, float64(time.Since(t0).Milliseconds()))
		s.fail(w, http.StatusGatewayTimeout, "tempo limite de processamento excedido", ctx.Err())
		return
	}
	millis := float64(time.Since(t0).Microseconds()) / 1000
	if o.res == nil {
		s.st.FailAnalysis(id, millis)
		s.fail(w, http.StatusInternalServerError, "falha no processamento da imagem", o.err)
		return
	}

	// preserva a imagem original (formato real detectado, nome gerado pelo servidor)
	origName := "original." + map[string]string{"jpeg": "jpg", "png": "png", "bmp": "png"}[format]
	if err := saveOriginal(filepath.Join(dir, origName), img, format); err != nil {
		s.log.Printf("aviso: não foi possível gravar a original: %v", err)
		origName = ""
	}

	status := "concluido"
	if o.err != nil {
		status = "erro"
	} else if len(o.res.Plates) == 0 {
		status = "sem_placas"
	}
	var steps []store.Step
	for _, st := range o.res.Steps {
		steps = append(steps, store.Step{Name: st.Name, Title: st.Title, File: st.File, Millis: st.Millis, Status: st.Status, Detail: st.Detail})
	}
	var plates []store.Plate
	for _, p := range o.res.Plates {
		plates = append(plates, store.Plate{X: p.X, Y: p.Y, W: p.W, H: p.H, File: p.CropFile, Score: p.Score, Method: p.Method})
	}
	if _, err := s.st.FinishAnalysis(id, status, millis, o.res.Width, o.res.Height, origName, steps, plates); err != nil {
		s.fail(w, http.StatusInternalServerError, "erro ao gravar o resultado", err)
		return
	}
	a, err := s.st.GetAnalysis(id)
	if err != nil {
		s.fail(w, http.StatusInternalServerError, "erro ao ler o resultado", err)
		return
	}
	s.log.Printf("análise %d: %q %dx%d, %d placa(s), %v, status=%s", id, name, o.res.Width, o.res.Height, len(plates), time.Since(t0).Round(time.Millisecond), status)
	if o.err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]any{"error": o.err.Error(), "analysis": a})
		return
	}
	writeJSON(w, http.StatusOK, a)
}

// saveOriginal regrava a imagem enviada no próprio formato (a partir do que foi decodificado).
func saveOriginal(path string, img image.Image, format string) error {
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()
	switch format {
	case "jpeg":
		return jpeg.Encode(f, img, &jpeg.Options{Quality: 95})
	default: // png e bmp são regravados em PNG sem perdas
		return png.Encode(f, img)
	}
}

// ---------- histórico, resultados e métricas ----------

func (s *Server) list(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	limit, _ := strconv.Atoi(q.Get("limit"))
	offset, _ := strconv.Atoi(q.Get("offset"))
	if limit <= 0 || limit > 100 {
		limit = 20
	}
	if offset < 0 {
		offset = 0
	}
	status := q.Get("status")
	switch status {
	case "", "concluido", "sem_placas", "erro":
	default:
		status = ""
	}
	items, total, err := s.st.List(q.Get("q"), status, limit, offset)
	if err != nil {
		s.fail(w, http.StatusInternalServerError, "erro ao listar o histórico", err)
		return
	}
	if items == nil {
		items = []store.Analysis{}
	}
	writeJSON(w, http.StatusOK, map[string]any{"items": items, "total": total})
}

func (s *Server) get(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(r)
	if !ok {
		s.fail(w, http.StatusBadRequest, "id inválido", nil)
		return
	}
	a, err := s.st.GetAnalysis(id)
	if errors.Is(err, sql.ErrNoRows) {
		s.fail(w, http.StatusNotFound, "análise não encontrada", nil)
		return
	} else if err != nil {
		s.fail(w, http.StatusInternalServerError, "erro ao consultar a análise", err)
		return
	}
	writeJSON(w, http.StatusOK, a)
}

func (s *Server) remove(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(r)
	if !ok {
		s.fail(w, http.StatusBadRequest, "id inválido", nil)
		return
	}
	if err := s.st.DeleteAnalysis(id); errors.Is(err, sql.ErrNoRows) {
		s.fail(w, http.StatusNotFound, "análise não encontrada", nil)
		return
	} else if err != nil {
		s.fail(w, http.StatusInternalServerError, "erro ao excluir", err)
		return
	}
	if err := os.RemoveAll(filepath.Join(s.results, strconv.FormatInt(id, 10))); err != nil {
		s.log.Printf("aviso: não foi possível remover os arquivos da análise %d: %v", id, err)
	}
	writeJSON(w, http.StatusOK, map[string]bool{"ok": true})
}

func (s *Server) stats(w http.ResponseWriter, r *http.Request) {
	st, err := s.st.Stats()
	if err != nil {
		s.fail(w, http.StatusInternalServerError, "erro ao calcular os indicadores", err)
		return
	}
	writeJSON(w, http.StatusOK, st)
}

// serveResult entrega imagens geradas. Aceita só id numérico e nome simples de
// arquivo de imagem (sem separadores), o que impede path traversal.
func (s *Server) serveResult(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(r)
	file := r.PathValue("file")
	ext := strings.ToLower(filepath.Ext(file))
	if !ok || !safeFile.MatchString(file) || strings.Contains(file, "..") || (ext != ".png" && ext != ".jpg" && ext != ".bmp") {
		http.NotFound(w, r)
		return
	}
	p := filepath.Join(s.results, strconv.FormatInt(id, 10), file)
	if rel, err := filepath.Rel(s.results, p); err != nil || strings.HasPrefix(rel, "..") {
		http.NotFound(w, r)
		return
	}
	w.Header().Set("Cache-Control", "private, max-age=600")
	http.ServeFile(w, r, p)
}

// ---------- OCR (feito no navegador) e gabarito ----------

func (s *Server) saveOCR(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(r)
	if !ok {
		s.fail(w, http.StatusBadRequest, "id inválido", nil)
		return
	}
	var body struct {
		Text       string  `json:"text"`
		Confidence float64 `json:"confidence"`
		Lang       string  `json:"lang"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 64<<10)).Decode(&body); err != nil {
		s.fail(w, http.StatusBadRequest, "JSON inválido", err)
		return
	}
	if len([]rune(body.Text)) > 64 || body.Confidence < 0 || body.Confidence > 100 || !langRe.MatchString(body.Lang) {
		s.fail(w, http.StatusBadRequest, "dados de OCR inválidos", nil)
		return
	}
	if err := s.st.SaveOCR(id, body.Text, body.Confidence, body.Lang); errors.Is(err, sql.ErrNoRows) {
		s.fail(w, http.StatusNotFound, "placa não encontrada", nil)
		return
	} else if err != nil {
		s.fail(w, http.StatusInternalServerError, "erro ao gravar o OCR", err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]bool{"ok": true})
}

func (s *Server) saveTruth(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(r)
	if !ok {
		s.fail(w, http.StatusBadRequest, "id inválido", nil)
		return
	}
	var body struct {
		Truth string `json:"truth"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 64<<10)).Decode(&body); err != nil || len([]rune(body.Truth)) > 64 {
		s.fail(w, http.StatusBadRequest, "gabarito inválido", err)
		return
	}
	if err := s.st.SaveGroundTruth(id, body.Truth); errors.Is(err, sql.ErrNoRows) {
		s.fail(w, http.StatusNotFound, "placa não encontrada", nil)
		return
	} else if err != nil {
		s.fail(w, http.StatusInternalServerError, "erro ao gravar o gabarito", err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]bool{"ok": true})
}

func init() { image.RegisterFormat("bmp", "BM????\x00\x00\x00\x00", bmp.Decode, bmp.DecodeConfig) }
