package server

import (
	"bytes"
	"encoding/json"
	"io"
	"log"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"placas/internal/store"
)

func newTestServer(t *testing.T) (*httptest.Server, string) {
	t.Helper()
	dir := t.TempDir()
	st, err := store.Open(filepath.Join(dir, "t.db"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { st.Close() })
	s, err := New(st, dir, log.New(io.Discard, "", 0))
	if err != nil {
		t.Fatal(err)
	}
	ts := httptest.NewServer(s.Handler())
	t.Cleanup(ts.Close)
	return ts, dir
}

func upload(t *testing.T, ts *httptest.Server, filename string, data []byte) *http.Response {
	t.Helper()
	var b bytes.Buffer
	w := multipart.NewWriter(&b)
	fw, _ := w.CreateFormFile("image", filename)
	fw.Write(data)
	w.Close()
	resp, err := http.Post(ts.URL+"/api/analyze", w.FormDataContentType(), &b)
	if err != nil {
		t.Fatal(err)
	}
	return resp
}

func example(t *testing.T, name string) []byte {
	t.Helper()
	b, err := os.ReadFile(filepath.Join("..", "..", "web", "static", "exemplos", name))
	if err != nil {
		t.Skip(err)
	}
	return b
}

func TestPagesRender(t *testing.T) {
	ts, _ := newTestServer(t)
	for _, p := range []string{"/", "/processar", "/historico", "/dashboard", "/sobre", "/analise/1"} {
		r, _ := http.Get(ts.URL + p)
		body, _ := io.ReadAll(r.Body)
		if r.StatusCode != 200 || !strings.Contains(string(body), "PlacaVision") {
			t.Errorf("%s: status %d", p, r.StatusCode)
		}
		if r.Header.Get("Content-Security-Policy") == "" {
			t.Errorf("%s: sem CSP", p)
		}
	}
	if r, _ := http.Get(ts.URL + "/static/vendor/tesseract/lang/eng.traineddata.gz"); r.StatusCode != 200 {
		t.Errorf("modelo OCR local não é servido: %d", r.StatusCode)
	}
}

func TestUploadValidation(t *testing.T) {
	ts, _ := newTestServer(t)
	cases := []struct {
		name string
		file string
		data []byte
		want int
	}{
		{"extensão proibida", "x.gif", []byte("GIF89a"), 415},
		{"conteúdo falso com extensão jpg", "x.jpg", []byte("isto não é uma imagem"), 415},
		{"vazio", "x.png", nil, 415},
	}
	for _, c := range cases {
		r := upload(t, ts, c.file, c.data)
		if r.StatusCode != c.want {
			t.Errorf("%s: status %d, esperado %d", c.name, r.StatusCode, c.want)
		}
	}
	big := bytes.Repeat([]byte{0}, 16<<20)
	if r := upload(t, ts, "big.jpg", big); r.StatusCode != 413 {
		t.Errorf("arquivo grande: status %d, esperado 413", r.StatusCode)
	}
}

func TestFullFlow(t *testing.T) {
	ts, dir := newTestServer(t)
	resp := upload(t, ts, "../../etc/frontal.jpg", example(t, "frontal.jpg"))
	if resp.StatusCode != 200 {
		b, _ := io.ReadAll(resp.Body)
		t.Fatalf("status %d: %s", resp.StatusCode, b)
	}
	var a store.Analysis
	json.NewDecoder(resp.Body).Decode(&a)
	if a.Status != "concluido" || len(a.Plates) == 0 || strings.Contains(a.Filename, "/") || strings.Contains(a.Filename, "..") {
		t.Fatalf("análise inesperada: %+v", a)
	}
	if _, err := os.Stat(filepath.Join(dir, "results", "1", a.Original)); err != nil {
		t.Fatalf("a imagem original deveria estar preservada: %v", err)
	}
	// imagem gerada acessível; path traversal bloqueado
	step := a.Steps[0].File
	if r, _ := http.Get(ts.URL + "/results/1/" + step); r.StatusCode != 200 {
		t.Errorf("resultado inacessível: %d", r.StatusCode)
	}
	for _, bad := range []string{"/results/1/..%2f..%2ft.db", "/results/1/%2e%2e/t.db", "/results/abc/x.png", "/results/1/t.db", "/results/1/a%00.png"} {
		if r, _ := http.Get(ts.URL + bad); r.StatusCode == 200 {
			t.Errorf("%s não deveria ser servido", bad)
		}
	}
	// OCR
	pid := a.Plates[0].ID
	post := func(path, body string) int {
		r, _ := http.Post(ts.URL+path, "application/json", strings.NewReader(body))
		return r.StatusCode
	}
	if c := post("/api/plates/"+itoa(pid)+"/ocr", `{"text":"1234 ABC","confidence":91,"lang":"eng"}`); c != 200 {
		t.Fatalf("salvar OCR: %d", c)
	}
	if c := post("/api/plates/"+itoa(pid)+"/ocr", `{"text":"x","confidence":500,"lang":"eng"}`); c != 400 {
		t.Errorf("confiança inválida deveria dar 400, deu %d", c)
	}
	if c := post("/api/plates/"+itoa(pid)+"/ocr", `{"text":"x","confidence":1,"lang":"../../x"}`); c != 400 {
		t.Errorf("idioma inválido deveria dar 400, deu %d", c)
	}
	if c := post("/api/plates/99999/ocr", `{"text":"x","confidence":1,"lang":"eng"}`); c != 404 {
		t.Errorf("placa inexistente deveria dar 404, deu %d", c)
	}
	if c := post("/api/plates/"+itoa(pid)+"/truth", `{"truth":"1234 ABD"}`); c != 200 {
		t.Fatalf("gabarito: %d", c)
	}
	// histórico, estatísticas
	var list struct {
		Items []store.Analysis `json:"items"`
		Total int              `json:"total"`
	}
	r, _ := http.Get(ts.URL + "/api/analyses?q=1234")
	json.NewDecoder(r.Body).Decode(&list)
	if list.Total != 1 {
		t.Errorf("a busca pelo texto reconhecido deveria achar 1 análise, achou %d", list.Total)
	}
	var st store.Stats
	r, _ = http.Get(ts.URL + "/api/stats")
	json.NewDecoder(r.Body).Decode(&st)
	if st.Images != 1 || st.Recognized != 1 || st.AvgCER == nil || *st.AvgCER != 1.0/8 {
		t.Errorf("estatísticas inesperadas: %+v", st)
	}
	// exclusão remove banco e arquivos
	req, _ := http.NewRequest("DELETE", ts.URL+"/api/analyses/1", nil)
	if r, _ := http.DefaultClient.Do(req); r.StatusCode != 200 {
		t.Fatalf("excluir: %d", r.StatusCode)
	}
	if _, err := os.Stat(filepath.Join(dir, "results", "1")); !os.IsNotExist(err) {
		t.Errorf("a pasta de resultados deveria ter sido removida")
	}
	if r, _ := http.Get(ts.URL + "/api/analyses/1"); r.StatusCode != 404 {
		t.Errorf("análise excluída deveria dar 404")
	}
}

func TestNoPlatesImage(t *testing.T) {
	ts, _ := newTestServer(t)
	resp := upload(t, ts, "sem_placa.jpg", example(t, "sem_placa.jpg"))
	var a store.Analysis
	json.NewDecoder(resp.Body).Decode(&a)
	if resp.StatusCode != 200 || a.Status != "sem_placas" || a.TotalPlate != 0 {
		t.Fatalf("imagem sem placa: status HTTP %d, %+v", resp.StatusCode, a)
	}
}

func itoa(n int64) string { b, _ := json.Marshal(n); return string(b) }

// makeBMP monta um BMP de 24 bits (64x64, cinza) à mão, para testar o leitor BMP embutido.
func makeBMP(w, h int) []byte {
	rowSize := (w*3 + 3) &^ 3
	size := 54 + rowSize*h
	b := make([]byte, size)
	le32 := func(o int, v int) { b[o], b[o+1], b[o+2], b[o+3] = byte(v), byte(v>>8), byte(v>>16), byte(v>>24) }
	b[0], b[1] = 'B', 'M'
	le32(2, size)
	le32(10, 54)
	le32(14, 40)
	le32(18, w)
	le32(22, h)
	b[26], b[28] = 1, 24
	for i := 54; i < size; i++ {
		b[i] = 128
	}
	return b
}

func TestBMPUploadAccepted(t *testing.T) {
	ts, _ := newTestServer(t)
	resp := upload(t, ts, "pequena.bmp", makeBMP(64, 64))
	var a store.Analysis
	json.NewDecoder(resp.Body).Decode(&a)
	if resp.StatusCode != 200 || a.Width != 64 || a.Original != "original.png" {
		t.Fatalf("BMP deveria ser aceito: HTTP %d, %+v", resp.StatusCode, a)
	}
}
