// PlacaVision: detecção de placas de veículos egípcios com PDI em Go puro.
package main

import (
	"context"
	"flag"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"runtime"
	"time"

	"placas/internal/server"
	"placas/internal/store"
)

func main() {
	addr := flag.String("addr", "127.0.0.1:8080", "endereço do servidor HTTP")
	data := flag.String("data", "dados", "pasta de dados (banco, resultados e logs)")
	open := flag.Bool("abrir", runtime.GOOS == "windows", "abrir o navegador ao iniciar")
	eval := flag.String("avaliar", "", "pasta com imagens e anotações YOLO (.txt) para avaliar a detecção")
	flag.Parse()

	if *eval != "" {
		if err := evaluate(*eval); err != nil {
			fmt.Fprintln(os.Stderr, "erro:", err)
			os.Exit(1)
		}
		return
	}

	if err := os.MkdirAll(filepath.Join(*data, "logs"), 0o755); err != nil {
		fmt.Fprintln(os.Stderr, "não foi possível criar a pasta de dados:", err)
		os.Exit(1)
	}
	var out io.Writer = os.Stdout
	if f, err := os.OpenFile(filepath.Join(*data, "logs", "app.log"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644); err == nil {
		defer f.Close()
		out = io.MultiWriter(os.Stdout, f)
	}
	lg := log.New(out, "", log.LstdFlags)

	st, err := store.Open(filepath.Join(*data, "placas.db"))
	if err != nil {
		lg.Fatalf("erro ao abrir o banco SQLite: %v", err)
	}
	defer st.Close()
	srv, err := server.New(st, *data, lg)
	if err != nil {
		lg.Fatalf("erro ao iniciar o servidor: %v", err)
	}
	ln, err := net.Listen("tcp", *addr)
	if err != nil {
		lg.Fatalf("não foi possível usar %s (porta ocupada?): %v. Use -addr 127.0.0.1:8081", *addr, err)
	}
	hs := &http.Server{
		Handler:           srv.Handler(),
		ReadHeaderTimeout: 10 * time.Second,
		ReadTimeout:       60 * time.Second,
		WriteTimeout:      3 * time.Minute,
		IdleTimeout:       2 * time.Minute,
	}
	url := "http://" + *addr
	lg.Printf("PlacaVision em %s  (dados em %s) — Ctrl+C para encerrar", url, *data)
	if *open {
		go func() { time.Sleep(600 * time.Millisecond); openBrowser(url) }()
	}
	go func() {
		if err := hs.Serve(ln); err != nil && err != http.ErrServerClosed {
			lg.Fatalf("servidor: %v", err)
		}
	}()
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt)
	<-stop
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	hs.Shutdown(ctx)
	lg.Println("servidor encerrado")
}

func openBrowser(url string) {
	var cmd *exec.Cmd
	switch runtime.GOOS {
	case "windows":
		cmd = exec.Command("rundll32", "url.dll,FileProtocolHandler", url)
	case "darwin":
		cmd = exec.Command("open", url)
	default:
		cmd = exec.Command("xdg-open", url)
	}
	_ = cmd.Start()
}
