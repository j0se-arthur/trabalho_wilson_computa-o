package main

import (
	"fmt"
	"image"
	_ "image/jpeg"
	_ "image/png"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"placas/internal/metrics"
	"placas/internal/pdi"
	_ "placas/internal/server"
)

// evaluate roda a detecção sobre uma pasta de imagens com anotações YOLO
// ("classe cx cy w h", valores normalizados, um arquivo .txt por imagem) e
// imprime precisão, recall, IoU médio e tempo médio.
func evaluate(dir string) error {
	files, _ := filepath.Glob(filepath.Join(dir, "*"))
	var tp, fp, fn, n int
	var sumIoU float64
	var total time.Duration
	tmp, err := os.MkdirTemp("", "placas-eval")
	if err != nil {
		return err
	}
	defer os.RemoveAll(tmp)
	for _, f := range files {
		ext := strings.ToLower(filepath.Ext(f))
		if ext != ".jpg" && ext != ".jpeg" && ext != ".png" {
			continue
		}
		labels, err := os.ReadFile(strings.TrimSuffix(f, filepath.Ext(f)) + ".txt")
		if err != nil {
			continue // sem anotação: ignora
		}
		fh, err := os.Open(f)
		if err != nil {
			return err
		}
		img, _, err := image.Decode(fh)
		fh.Close()
		if err != nil {
			fmt.Printf("%s: não foi possível decodificar (%v)\n", filepath.Base(f), err)
			continue
		}
		W, H := float64(img.Bounds().Dx()), float64(img.Bounds().Dy())
		var truth []image.Rectangle
		for _, line := range strings.Split(string(labels), "\n") {
			p := strings.Fields(line)
			if len(p) < 5 {
				continue
			}
			v := make([]float64, 4)
			for i := range v {
				v[i], _ = strconv.ParseFloat(p[i+1], 64)
			}
			truth = append(truth, image.Rect(int((v[0]-v[2]/2)*W), int((v[1]-v[3]/2)*H), int((v[0]+v[2]/2)*W), int((v[1]+v[3]/2)*H)))
		}
		t0 := time.Now()
		res, err := pdi.Process(img, filepath.Join(tmp, "x"))
		total += time.Since(t0)
		if res == nil {
			return err
		}
		var pred []image.Rectangle
		for _, p := range res.Plates {
			pred = append(pred, image.Rect(p.X, p.Y, p.X+p.W, p.Y+p.H))
		}
		d := metrics.EvaluateDetection(pred, truth, 0.5)
		tp, fp, fn = tp+d.TP, fp+d.FP, fn+d.FN
		sumIoU += d.MeanIoU * float64(d.TP)
		n++
		fmt.Printf("%-28s verdadeiras=%d detectadas=%d TP=%d FP=%d FN=%d\n", filepath.Base(f), len(truth), len(pred), d.TP, d.FP, d.FN)
	}
	if n == 0 {
		return fmt.Errorf("nenhuma imagem com anotação .txt (YOLO) em %q", dir)
	}
	prec, rec, miou := 0.0, 0.0, 0.0
	if tp+fp > 0 {
		prec = float64(tp) / float64(tp+fp)
	}
	if tp+fn > 0 {
		rec = float64(tp) / float64(tp+fn)
	}
	if tp > 0 {
		miou = sumIoU / float64(tp)
	}
	fmt.Printf("\nImagens: %d | TP=%d FP=%d FN=%d (IoU >= 0,5)\nPrecisão: %.1f%% | Recall: %.1f%% | IoU médio (TP): %.3f | Tempo médio: %v\n",
		n, tp, fp, fn, prec*100, rec*100, miou, (total / time.Duration(n)).Round(time.Millisecond))
	return nil
}
