@echo off
cd /d "%~dp0"
echo Iniciando PlacaVision... (feche esta janela para encerrar)
PlacaVision.exe
pause
