# Tutorial de uso – PlacaVision

Sistema de detecção e leitura de placas de veículos egípcios (Tema 2 – *Cars Brands in Egypt*).
O processamento de imagens é feito em **Go puro**; o OCR roda no navegador com **Tesseract.js**.
**Não precisa instalar nada** (nem Go, nem OpenCV, nem Tesseract) e **funciona sem internet**.

## 1. Iniciar o sistema (Windows 10/11, 64 bits)

1. Extraia o ZIP inteiro numa pasta (por exemplo `C:\PlacaVision`). Não execute de dentro do ZIP.
2. Dê dois cliques em **`iniciar.bat`** (ou em `PlacaVision.exe`).
3. Uma janela preta (console) vai abrir e o navegador abrirá em **http://127.0.0.1:8080**.
   - Se o navegador não abrir, abra você mesmo e digite esse endereço.
   - **Deixe a janela preta aberta**: ela é o servidor. Fechar a janela (ou Ctrl+C) encerra o sistema.
4. Na primeira execução o Windows pode mostrar *"O Windows protegeu o computador"* (o programa não é assinado digitalmente). Clique em **Mais informações → Executar assim mesmo**. Se o Firewall perguntar algo, pode negar o acesso: o sistema só usa o seu próprio computador.
5. Será criada a pasta `dados\` ao lado do executável, com o banco SQLite (`placas.db`), as imagens geradas (`results\`) e o log (`logs\app.log`). Nada precisa ser configurado.

Se a porta 8080 estiver ocupada: abra o Prompt de Comando na pasta e rode
`PlacaVision.exe -addr 127.0.0.1:8081` (e acesse http://127.0.0.1:8081).

## 2. Processar uma imagem

1. Clique em **Processar** (menu superior) ou em *Iniciar processamento* na página inicial.
2. Arraste uma foto para a área pontilhada ou clique nela para escolher o arquivo (JPG, JPEG, PNG ou BMP, até 15 MB).
   Para testar rápido, abra *"Usar uma imagem de exemplo"* e clique em uma das seis imagens (são sintéticas, geradas só para teste).
3. Confira a pré-visualização e escolha os **idiomas do OCR**:
   - *Árabe + Inglês* (padrão, recomendado para placas egípcias);
   - *Inglês* (letras latinas e números); *Árabe*.
4. Clique em **Iniciar análise**. O indicador de processamento aparece e, em cerca de 0,5 a 1 s, surgem os resultados.
5. O OCR começa automaticamente em cada placa. **Na primeira vez** o navegador carrega o motor de OCR (alguns segundos); depois fica rápido.

## 3. Entendendo o resultado

- **Placas:** cada placa detectada mostra o recorte, a posição (x, y), o tamanho, a pontuação da detecção e se houve *correção de perspectiva* ou *recorte convencional*. Abaixo vem o **texto reconhecido** e a **confiança do OCR**.
  A tabela de tentativas mostra todas as versões testadas (cinza normalizada, Otsu, adaptativa) em dois modos de segmentação; o sistema grava a de maior confiança.
- **Etapas do processamento:** imagens de cada etapa (original, cinza, gaussiano, bilateral, equalizada, limiarização adaptativa, Sobel, bordas, morfologia, contornos, detecção) com o tempo gasto em cada uma. Clique em qualquer imagem para ampliar.
  Na imagem de **contornos**: vermelho = região rejeitada, amarelo = aceita, verde = selecionada como placa.
- **Texto correto (gabarito):** se você souber a placa real, digite no campo e clique em *Salvar gabarito*. O sistema calcula o **CER** (taxa de erro de caracteres) daquela leitura. Isso é o que alimenta as métricas de exatidão do dashboard.
- **Executar OCR novamente:** refaz a leitura (por exemplo, trocando o idioma).

> A "confiança" do OCR é uma estimativa do próprio Tesseract e **não** garante que o texto esteja certo. O texto reconhecido é exibido exatamente como o OCR devolveu, sem correções automáticas.

## 4. Histórico

- **Histórico** lista todas as análises (nome, data, texto reconhecido, nº de placas, tempo e status).
- Use a busca (nome do arquivo ou texto reconhecido) e o filtro de status. Clique no nome para abrir a análise completa.
- Em uma análise, o botão **Excluir** remove o registro do banco e os arquivos gerados.

## 5. Dashboard

Mostra, com dados reais do banco: total de imagens, placas detectadas, reconhecimentos realizados e sem resultado, taxa de reconhecimento, tempo médio de processamento, CER médio e acerto exato (estes dois só aparecem depois que você informa gabaritos), além de gráficos (Chart.js).

## 6. Avaliação da detecção (opcional, linha de comando)

Se você tiver imagens com anotações no formato **YOLO** (um `.txt` com o mesmo nome da imagem; linhas `classe cx cy largura altura`, valores de 0 a 1), rode:

```
PlacaVision.exe -avaliar C:\caminho\da\pasta
```

O programa imprime, por imagem, as detecções corretas (TP), falsas (FP) e perdidas (FN) e, no final, **precisão, recall, IoU médio e tempo médio** (acerto quando IoU ≥ 0,5).

## 7. Roteiro sugerido para a apresentação

1. Abra o sistema **antes** da aula e processe uma imagem para o OCR ficar carregado (o navegador guarda o motor depois da primeira vez).
2. Mostre a página inicial e explique que o PDI é em Go puro (sem OpenCV) e o banco é SQLite.
3. Em *Processar*, use a imagem de exemplo "Placa frontal": mostre as etapas (cinza → gaussiano → bilateral → equalização → Sobel → morfologia → contornos → detecção → recorte → binarizações) e o texto lido.
4. Mostre a imagem "Sem placa" (o sistema não inventa placa) e "Placa inclinada" (discuta a limitação: neste exemplo a leitura falha).
5. Abra o **Histórico** (busca) e o **Dashboard** (indicadores reais).
6. Se tiver fotos reais de placas egípcias, processe algumas e informe os gabaritos para mostrar o CER.

## 8. Problemas comuns

| Sintoma | O que fazer |
|---|---|
| Janela fecha logo ao abrir | Rode pelo Prompt de Comando na pasta (`PlacaVision.exe`) para ler a mensagem de erro; costuma ser porta ocupada (use `-addr 127.0.0.1:8081`) ou pasta sem permissão de escrita (extraia para fora de `Arquivos de Programas`). |
| "Formato não permitido" | Só JPG, JPEG, PNG e BMP são aceitos (até 15 MB, mínimo 64×64 px). |
| Nenhuma placa detectada | Veja a imagem de *contornos* para entender o motivo. Tente uma foto mais próxima, frontal e com boa luz. |
| Texto do OCR errado ou vazio | Normal em fotos difíceis. Tente outro idioma, outra foto, ou use o gabarito para registrar o erro. |
| OCR "carregando" por muito tempo | A primeira carga leva alguns segundos. Se falhar, recarregue a página (F5) e tente de novo. Use Chrome, Edge ou Firefox atualizados. |
