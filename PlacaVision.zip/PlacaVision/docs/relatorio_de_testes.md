# Relatório de testes – PlacaVision

Data da execução: 17/11/2026 · Ambiente: Linux x86-64, Go 1.22.2 · Comando: `go test -count=1 -v -cover ./...`

## 1. Resumo
- **35 testes automatizados, todos aprovados** (4 pacotes com testes).
- Cobertura de instruções: metrics 89,1% · pdi 93,7% · store 81,0% · server 59,2%.
- Teste manual automatizado em navegador real (Chromium via Playwright): enviar imagem de exemplo, executar o OCR no navegador com a política de segurança (CSP) ativa, abrir dashboard e histórico, sem erros no console.
- **Não executado:** o `PlacaVision.exe` em um Windows real (foi apenas gerado por compilação cruzada); fotos reais de placas egípcias (não havia dataset disponível).

## 2. O que cada grupo de testes cobre
| Área | Testes |
|---|---|
| Aquisição e validação | extensão proibida, conteúdo falso com extensão .jpg, arquivo vazio, arquivo > 15 MB, BMP aceito |
| Conversão para cinza, filtros | `TestGrayConversion`, `TestGaussian…`, `TestBilateralKeepsEdge`, `TestEqualizeHist…` |
| Limiarização | `TestOtsu…`, `TestAdaptiveThreshold…` |
| Bordas, morfologia, contornos | `TestSobelFindsVerticalEdge`, `TestMorphologyAndComponents` |
| Detecção | `TestEvaluateRejectsNonPlateShapes` (quadrado não é placa), `TestPipelineOnExamples` (6 imagens: frontal, inclinada, pouca luz, baixa resolução, dois veículos, sem placa), `TestPipelineFrontalPlateLocation` (IoU ≥ 0,5) |
| Recorte e perspectiva | `TestHomographyIdentityAndWarp`, `TestAnalyzeQuad` |
| Melhoria da placa | `TestEnhancePlateProducesDarkTextOnLight` |
| Robustez | `TestPipelineTinyImageDoesNotPanic` |
| Banco de dados | criação automática, inserção/consulta, exclusão em cascata, busca/filtros, estatísticas reais, OCR/CER |
| Servidor/API | páginas, CSP, fluxo completo (upload → OCR → gabarito → histórico → estatísticas → exclusão), path traversal, validação de entradas |
| Métricas | IoU, CER (inclui dígitos árabes), precisão/recall |
| OCR | testado manualmente (seção 4), pois roda no navegador (JavaScript) |

## 3. Saída dos testes
```
placas		coverage: 0.0% of statements
	placas/internal/bmp		coverage: 0.0% of statements
=== RUN   TestIoU
--- PASS: TestIoU (0.00s)
=== RUN   TestCER
--- PASS: TestCER (0.00s)
=== RUN   TestEvaluateDetection
--- PASS: TestEvaluateDetection (0.00s)
PASS
coverage: 89.1% of statements
ok  	placas/internal/metrics	0.006s	coverage: 89.1% of statements
=== RUN   TestGrayConversion
--- PASS: TestGrayConversion (0.00s)
=== RUN   TestGaussianPreservesConstantAndSmoothsImpulse
--- PASS: TestGaussianPreservesConstantAndSmoothsImpulse (0.00s)
=== RUN   TestBilateralKeepsEdge
--- PASS: TestBilateralKeepsEdge (0.00s)
=== RUN   TestEqualizeHistStretchesContrast
--- PASS: TestEqualizeHistStretchesContrast (0.00s)
=== RUN   TestOtsuSeparatesTwoLevels
--- PASS: TestOtsuSeparatesTwoLevels (0.00s)
=== RUN   TestAdaptiveThresholdDetectsDarkTextOnGradient
--- PASS: TestAdaptiveThresholdDetectsDarkTextOnGradient (0.00s)
=== RUN   TestSobelFindsVerticalEdge
--- PASS: TestSobelFindsVerticalEdge (0.00s)
=== RUN   TestMorphologyAndComponents
--- PASS: TestMorphologyAndComponents (0.00s)
=== RUN   TestHomographyIdentityAndWarp
--- PASS: TestHomographyIdentityAndWarp (0.00s)
=== RUN   TestAnalyzeQuad
--- PASS: TestAnalyzeQuad (0.00s)
=== RUN   TestEvaluateRejectsNonPlateShapes
--- PASS: TestEvaluateRejectsNonPlateShapes (0.00s)
=== RUN   TestIoU
--- PASS: TestIoU (0.00s)
=== RUN   TestPipelineOnExamples
=== RUN   TestPipelineOnExamples/frontal.jpg
=== RUN   TestPipelineOnExamples/inclinada.jpg
=== RUN   TestPipelineOnExamples/pouca_luz.jpg
=== RUN   TestPipelineOnExamples/baixa_resolucao.jpg
=== RUN   TestPipelineOnExamples/dois_carros.jpg
=== RUN   TestPipelineOnExamples/sem_placa.jpg
--- PASS: TestPipelineOnExamples (3.35s)
    --- PASS: TestPipelineOnExamples/frontal.jpg (0.64s)
    --- PASS: TestPipelineOnExamples/inclinada.jpg (0.64s)
    --- PASS: TestPipelineOnExamples/pouca_luz.jpg (0.58s)
    --- PASS: TestPipelineOnExamples/baixa_resolucao.jpg (0.17s)
    --- PASS: TestPipelineOnExamples/dois_carros.jpg (0.68s)
    --- PASS: TestPipelineOnExamples/sem_placa.jpg (0.63s)
=== RUN   TestPipelineFrontalPlateLocation
--- PASS: TestPipelineFrontalPlateLocation (0.66s)
=== RUN   TestPipelineTinyImageDoesNotPanic
--- PASS: TestPipelineTinyImageDoesNotPanic (0.00s)
=== RUN   TestEnhancePlateProducesDarkTextOnLight
--- PASS: TestEnhancePlateProducesDarkTextOnLight (0.02s)
PASS
coverage: 93.7% of statements
ok  	placas/internal/pdi	4.038s	coverage: 93.7% of statements
=== RUN   TestPagesRender
--- PASS: TestPagesRender (0.05s)
=== RUN   TestUploadValidation
--- PASS: TestUploadValidation (0.58s)
=== RUN   TestFullFlow
--- PASS: TestFullFlow (0.70s)
=== RUN   TestNoPlatesImage
--- PASS: TestNoPlatesImage (0.53s)
=== RUN   TestBMPUploadAccepted
--- PASS: TestBMPUploadAccepted (0.01s)
PASS
coverage: 59.2% of statements
ok  	placas/internal/server	1.881s	coverage: 59.2% of statements
=== RUN   TestInsertGetAndCascadeDelete
--- PASS: TestInsertGetAndCascadeDelete (0.01s)
=== RUN   TestOCRStatusAndCER
--- PASS: TestOCRStatusAndCER (0.01s)
=== RUN   TestListFiltersAndSearch
--- PASS: TestListFiltersAndSearch (0.01s)
=== RUN   TestStatsUseRealData
--- PASS: TestStatsUseRealData (0.01s)
=== RUN   TestBidiMarksIgnoredInCER
--- PASS: TestBidiMarksIgnoredInCER (0.01s)
PASS
coverage: 81.0% of statements
ok  	placas/internal/store	0.039s	coverage: 81.0% of statements
```

## 4. Resultado real do pipeline completo nas 6 imagens de exemplo
As imagens são **sintéticas**. Detecção: pipeline em Go. OCR: Tesseract.js, idiomas árabe+inglês, 3 versões × 2 modos, melhor confiança (mesma lógica da interface).

| Imagem | Texto real | Placas detectadas | Leitura do OCR (confiança) | Avaliação |
|---|---|---|---|---|
| frontal | 1234 ABC | 2 | "1234 ABC" (92%) e "EGYPT مصر" (92%) | placa correta lida; a 2ª detecção é um falso positivo (faixa superior da placa) |
| inclinada | ٣٤٥٦ أ ب ج | 1 | leitura sem sentido (76%) | **placa localizada, OCR falhou** |
| pouca luz | 5678 XYZ | 1 | "5678 XYZ," (85%) | correta, com vírgula extra |
| baixa resolução | 9021 DEF | 1 | "9021 DEE" (87%) | 1 caractere errado |
| dois veículos | 4821 KLM / 7305 NPQ | 2 | "EGYPT مصر" nas duas (92%) | **as duas placas foram localizadas, mas o recorte pegou só a faixa superior** |
| sem placa | – | 0 | – | correto (sem falso positivo) |

Leitura: a **localização** encontrou as placas em 5 das 5 imagens que as contêm (com 1 falso positivo extra em 1 delas e nenhum na imagem sem placa); a **leitura completamente correta** ocorreu em 1 de 6 placas (e mais 2 com pequenos erros). A confiança do OCR foi alta (≥ 76%) inclusive em leituras erradas, o que confirma que ela **não** mede acerto.

Tempo do pipeline de PDI (servidor): ~0,15 s (imagem de 480×320) a ~0,65 s (1280×853).

## 5. Conclusões e limitações
- O sistema funciona de ponta a ponta (upload, PDI, OCR, banco, histórico, dashboard, métricas).
- O desempenho em **fotos reais** de placas egípcias **não foi medido**. Os parâmetros foram calibrados em imagens sintéticas e provavelmente exigirão ajuste; use `-avaliar` e o CER do dashboard com um dataset real para medir.
- Falhas observadas: recorte de apenas parte da placa, falso positivo em elementos com muitos traços verticais, OCR fraco em placa inclinada e em letras árabes.
