# Dataset

**O projeto não inclui um dataset real de placas egípcias.** O sistema inicia sem dataset algum.

Incluídas em `exemplos/` (e embutidas no programa) há **6 imagens sintéticas** desenhadas por script apenas para testes de regressão e demonstração: placa frontal, inclinada, pouca luz, baixa resolução, dois veículos e sem placa. Elas **não** representam fotos reais.

## Como obter um dataset real
Procure por "Egyptian license plates" em portais de datasets (por exemplo Kaggle ou Roboflow Universe). Antes de usar, confira e documente: origem, **licença**, quantidade de imagens, formato das anotações (YOLO ou COCO), critérios de seleção e limitações. Não foi verificado aqui nenhum dataset específico.

## Usando com o sistema
- Processamento: envie as imagens pela interface.
- Avaliação da detecção: coloque as imagens (`.jpg/.jpeg/.png`) e anotações YOLO (`mesmo_nome.txt`, `classe cx cy w h` normalizados) numa pasta e rode `PlacaVision.exe -avaliar pasta`. Se o dataset usar COCO, converta para YOLO antes.
- Avaliação do OCR: informe o texto correto de cada placa em *Texto correto (gabarito)* na página da análise; o dashboard mostra CER médio e acerto exato.
