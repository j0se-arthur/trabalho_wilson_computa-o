# Manual de instalação e compilação

## A. Só executar (recomendado)
Use o `PlacaVision.exe` do ZIP, conforme o `TUTORIAL.md`. Não há instalação nem dependências. Requisitos: Windows 10/11 64 bits e um navegador atual (Chrome, Edge ou Firefox).

## B. Compilar a partir do código-fonte
O projeto usa **CGO** só por causa do driver SQLite (`go-sqlite3`), que compila o SQLite em C. Por isso é preciso um compilador C. **Nenhuma biblioteca externa precisa ser baixada**: o código do driver já está em `third_party/go-sqlite3` e os arquivos web (inclusive Tesseract.js e modelos de idioma) estão em `web/static/vendor`.

### Windows (nativo) – passos
> Estes passos para Windows não foram executados no ambiente de desenvolvimento (Linux); o que foi verificado lá está na seção C.

1. **Go 1.22 ou superior:** baixe o instalador em https://go.dev/dl/ (Windows, amd64) e instale. Em um novo Prompt de Comando: `go version`.
2. **Compilador C (MinGW-w64):** instale o MSYS2 (https://www.msys2.org/), abra o terminal *MSYS2 UCRT64* e rode `pacman -S --needed mingw-w64-ucrt-x86_64-gcc`. Adicione `C:\msys64\ucrt64\bin` ao `PATH` do Windows e confira com `gcc --version`.
3. Abra o Prompt de Comando na pasta `codigo-fonte` e rode:
```
set CGO_ENABLED=1
go build -trimpath -ldflags "-s -w" -o PlacaVision.exe .
```
   A primeira compilação demora alguns minutos (compila o SQLite). Não é necessário `go get`/internet.
4. Execute: `PlacaVision.exe` e acesse http://127.0.0.1:8080.

Opções: `-addr 127.0.0.1:8081` (porta), `-data pasta` (onde ficam banco/resultados/logs), `-abrir=false` (não abrir o navegador), `-avaliar pasta` (avaliação com anotações YOLO).

GOPATH: não é necessário configurar; o projeto usa módulos (`go.mod`) e roda fora do GOPATH.

### Linux/macOS
`CGO_ENABLED=1 go build -o placavision .` (precisa de `gcc`/Xcode CLT) e `./placavision`.

## C. Como o `.exe` do ZIP foi gerado (verificado)
Em Linux (Ubuntu 24.04, Go 1.22.2 e `gcc-mingw-w64-x86-64`):
```
CGO_ENABLED=1 GOOS=windows GOARCH=amd64 CC=x86_64-w64-mingw32-gcc \
  go build -trimpath -ldflags "-s -w" -o PlacaVision.exe .
```
O executável resultante importa apenas `KERNEL32.dll` e `msvcrt.dll` (presentes em todo Windows). Foi **gerado**, mas **não executado** num Windows real aqui; a mesma base de código foi executada e testada em Linux (testes automatizados e teste no navegador).

## D. Testes
`go test ./...` (usa as imagens de `web/static/exemplos`). Para ver detalhes: `go test -v -cover ./...`.

## E. Dataset
Veja `dataset.md`.
