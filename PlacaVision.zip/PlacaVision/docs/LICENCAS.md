# Componentes de terceiros incluídos
- **Tesseract.js 5.1.1** e **tesseract.js-core** – Apache-2.0 (`web/static/vendor/tesseract`).
- **Modelos de idioma `eng` e `ara`** (`@tesseract.js-data`, variante *best_int*) – Apache-2.0.
- **Chart.js 4** – MIT (`web/static/vendor/chart`).
- **go-sqlite3 1.14.24** – MIT (`third_party/go-sqlite3`), que embute o **SQLite** (domínio público).
- **Leitor BMP** (`internal/bmp`) – cópia do pacote `golang.org/x/image/bmp`, licença BSD de 3 cláusulas (arquivo `LICENSE` na pasta).
