# Manual técnico – PlacaVision

## 1. Objetivo e problema
Localizar automaticamente placas de veículos egípcios em fotografias e extrair seus caracteres, aplicando técnicas de Processamento Digital de Imagens (PDI) e OCR. O sistema mostra cada etapa intermediária, registra os resultados em SQLite e permite avaliar o desempenho (IoU, precisão, recall, CER).

## 2. Decisões de projeto (e por quê)
| Decisão | Motivo |
|---|---|
| Linguagem principal: **Go** (backend, PDI, banco, regras de negócio) | Requisito do trabalho (evitar conflito com os colegas que usam Java e Python). |
| PDI em **Go puro**, sem GoCV/OpenCV | Instalar OpenCV + CGO no Windows é lento e frágil; em Go puro o projeto compila e roda em qualquer máquina, e as operações podem ser explicadas linha a linha. |
| OCR com **Tesseract.js** (JavaScript/WebAssembly) no navegador | Dispensa instalar o Tesseract no Windows. Modelos `eng` e `ara` ficam embutidos no executável (funciona offline). |
| SQLite via `mattn/go-sqlite3` (CGO) | O driver em Go puro (`modernc.org/sqlite`) não pôde ser baixado no ambiente de desenvolvimento. O executável final só depende de DLLs que já vêm no Windows. |
| Roteador do próprio `net/http` (Go 1.22) | Suporta `GET /rota/{id}`; dispensa Chi/Gin. |

Diferenças em relação ao enunciado original: GoCV, gosseract (Tesseract nativo), Chi/Gin, Bootstrap e `modernc.org/sqlite` **não** foram usados (ver tabela acima). O restante (pipeline de PDI, SQLite, histórico, dashboard, métricas, testes, manuais) foi implementado.

## 3. Arquitetura
```
main.go            inicialização, flags, servidor, encerramento
eval.go            modo -avaliar (métricas de detecção com anotações YOLO)
internal/pdi/      PDI: image.go filters.go morph.go detect.go perspective.go enhance.go pipeline.go
internal/store/    SQLite: criação automática, CRUD, busca, estatísticas
internal/server/   rotas HTTP, upload seguro, API JSON, arquivos de resultado
internal/metrics/  IoU, precisão/recall, Levenshtein, CER
internal/bmp/      leitor BMP (cópia do pacote golang.org/x/image/bmp, licença BSD)
web/templates      HTML (html/template)      web/static  CSS, JS, Tesseract.js, Chart.js, exemplos
third_party/       go-sqlite3 (MIT), copiado para compilar offline
```
Os arquivos de `web/` são embutidos no executável com `go:embed`.

## 4. Pipeline de PDI
Implementado em `internal/pdi/pipeline.go`. Cada etapa é uma função independente, executada com medição de tempo e `recover` (um erro/pânico numa etapa vira status "erro" e **não derruba o servidor**).

1. **Aquisição:** valida extensão e *conteúdo real* (`image.DecodeConfig`), limita 15 MB e 25 Mpx, decodifica JPG/PNG/BMP, informa largura, altura e canais. A original é preservada em disco. A imagem de trabalho é reduzida para no máximo 960 px de largura (média de área); o recorte final da placa é feito na imagem de **resolução original**.
2. **Pré-processamento:** cinza (luminância 0,299R+0,587G+0,114B); gaussiano 5×5 (σ=1); bilateral (raio 3, σs=3, σr=30: suaviza ruído preservando bordas); equalização de histograma (CDF); limiarização adaptativa (média local por imagem integral).
3. **Bordas:** Sobel; usa-se |Gx| porque os caracteres de uma placa geram muitas bordas **verticais**. Binarização por Otsu (limiar mínimo 15). Fechamento (largura ≈ W/40 × 11) para unir os caracteres numa só região e abertura 7×5 para remover ruído.
4. **Detecção:** componentes conexos (8-vizinhança) viram candidatos. Critérios (constantes em `detect.go`): tamanho mínimo/máximo; proporção medida no quadrilátero (2,2 a 10, ideal 4); preenchimento ≥ 0,45; **contraste interno** (p90−p10 ≥ 60); densidade de bordas; **traços verticais por linha** ≥ 3 (texto tem muitos). A pontuação combina esses fatores (aceita ≥ 0,55). Seleciona até 5 placas com supressão de sobreposição (IoU > 0,3 ou contenção > 0,5). A região de caracteres é então expandida verticalmente (proporção 3,6:1) para cobrir a placa. Nem todo retângulo é aceito como placa.
5. **Recorte e perspectiva:** os 4 cantos vêm dos pontos extremos do componente (min/max de x+y e x−y). `AnalyzeQuad` só aprova a **homografia** (sistema 8×8 por eliminação de Gauss, amostragem bilinear) se o quadrilátero for coerente (área, arestas opostas semelhantes, inclinação entre 1,5° e 25°); caso contrário usa **recorte convencional** e informa o motivo.
6. **Melhoria da placa:** cinza → altura normalizada para 160 px → gaussiano → normalização de contraste (percentis 2%–98%) → binarizações **Otsu** e **adaptativa** (51×51) → texto escuro em fundo claro → abertura/fechamento morfológicos → remoção de linhas/colunas de moldura quase totalmente escuras → margem branca de 16 px. A versão equalizada é gerada para comparação.
7. **OCR:** feito no navegador (Tesseract.js, LSTM). Para cada placa tenta 3 versões × 2 modos de segmentação (PSM 7 e 6) e grava a leitura de maior confiança, junto com idiomas e confiança. O texto **não é alterado**: só quebras de linha viram espaço e as pontas são aparadas.
8. **Pipeline integrado:** `pdi.Process(img, outDir)` devolve etapas, tempos e placas; o servidor grava tudo em transação.

### Conceitos de PDI e sua função
- *Filtros passa-baixa (gaussiano, bilateral):* reduzem ruído antes de derivar a imagem (derivadas amplificam ruído).
- *Equalização de histograma:* aumenta o contraste global, tornando as bordas mais comparáveis entre fotos claras e escuras.
- *Gradiente de Sobel:* aproxima a derivada espacial; picos = bordas.
- *Limiar de Otsu:* escolhe o limiar que maximiza a variância entre classes (automático, sem parâmetro).
- *Morfologia (dilatação/erosão, abertura/fechamento):* fechamento une traços vizinhos numa região; abertura remove pontos soltos.
- *Componentes conexos e descritores geométricos:* transformam pixels em objetos que podem ser classificados.
- *Transformação projetiva:* retifica uma placa fotografada de lado, normalizando sua geometria antes do OCR.

## 5. Banco de dados (SQLite)
Criado automaticamente em `dados/placas.db` (WAL, chaves estrangeiras ligadas). Tabelas:
- `analyses(id, original_filename, processed_at, processing_time, status, total_plates, width, height, original_path)`
- `plates(id, analysis_id→analyses ON DELETE CASCADE, recognized_text, confidence, detection_status, x, y, width, height, image_path, score, method, ocr_status, ocr_lang, ground_truth, cer)`
- `processing_steps(id, analysis_id→analyses ON DELETE CASCADE, step_name, image_path, execution_time, status, title, detail)`
Índices em `plates(analysis_id)`, `processing_steps(analysis_id)`, `analyses(processed_at)`, `analyses(status)`, `plates(ocr_status)`. As imagens ficam em disco (`dados/results/<id>/`); o banco guarda só os nomes.
Status da análise: `concluido`, `sem_placas`, `erro`. Status do OCR: `pendente`, `reconhecido`, `sem_resultado`.

## 6. API HTTP
`POST /api/analyze` (multipart, campo `image`) · `GET /api/analyses?q=&status=&limit=&offset=` · `GET|DELETE /api/analyses/{id}` · `POST /api/plates/{id}/ocr` · `POST /api/plates/{id}/truth` · `GET /api/stats` · `GET /results/{id}/{arquivo}`.

## 7. Segurança e estabilidade
Validação de extensão **e** conteúdo; limite de 15 MB e 25 Mpx; nome de arquivo do usuário só é exibido (sanitizado), nunca usado como caminho; arquivos servidos apenas por id numérico + nome simples `[A-Za-z0-9_.-]` com extensão de imagem (testado contra `..`, `%2e%2e`, `%00`); consultas SQL parametrizadas e `LIKE` com escape; cabeçalhos CSP, `X-Content-Type-Options`, `X-Frame-Options`; escuta apenas em `127.0.0.1` por padrão; no máximo 2 processamentos simultâneos (os demais esperam até 30 s); limite de 90 s por imagem; timeouts do servidor HTTP; `recover` global; cada requisição tem seus próprios objetos de imagem (nada é compartilhado entre goroutines); logs em `dados/logs/app.log`.

## 8. Métricas
`internal/metrics`: **IoU**, **precisão/recall** (correspondência gulosa, IoU ≥ 0,5), **CER** = distância de Levenshtein (por caractere Unicode) ÷ tamanho do gabarito. No CER ignoram-se **apenas** marcas invisíveis de direção do texto (LRM/RLM etc.), que o Tesseract insere em textos árabes; o texto armazenado não é alterado. A confiança do OCR nunca é usada como medida de acerto.

## 9. Limitações
- A detecção é **heurística** e foi ajustada e testada com **imagens sintéticas** (não há fotos reais de placas egípcias no projeto). Em fotos reais os parâmetros de `detect.go` e `pipeline.go` provavelmente precisarão de ajuste.
- Cenas com grades, faróis ou textos podem gerar falsos positivos; placas muito pequenas, muito inclinadas, com reflexos ou sombras podem falhar.
- Às vezes a região detectada é só uma faixa da placa (ex.: o texto "EGYPT/مصر") e não os caracteres principais (ver relatório de testes).
- O OCR genérico do Tesseract não é treinado para a fonte das placas egípcias; letras árabes de placas costumam ser lidas com erro.
- Placas de uma ou duas linhas, cores e padrões diferentes não são tratados separadamente.

## 10. Melhorias futuras
Detector treinado (ex.: modelo YOLO exportado para ONNX); fonte/modelo de OCR específico para placas egípcias; correção de perspectiva por detecção de linhas; separação de caracteres antes do OCR; GoCV/OpenCV como alternativa de implementação; calibração automática de parâmetros com um dataset anotado.
