# PlacaVision – detecção de placas de veículos egípcios (PDI em Go)

Projeto final de Processamento Digital de Imagens · Tema 2 (*Cars Brands in Egypt*).

- **Executar:** `PlacaVision.exe` / `iniciar.bat` → http://127.0.0.1:8080 (veja `docs/TUTORIAL.md`).
- **Código-fonte:** pasta `codigo-fonte/` (Go 1.22+; compilar: `docs/manual_instalacao.md`).
- **Stack:** Go (servidor, PDI em Go puro, SQLite) + JavaScript (interface, Tesseract.js para OCR no navegador).
- **Documentação:** `docs/` (tutorial, manual técnico, manual de instalação, relatório de testes, dataset, licenças).
- **Imagens de teste:** `exemplos/` (sintéticas).
